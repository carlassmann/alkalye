/* @ts-self-types="./jazz_wasm.d.ts" */

export class PendingNativeRead {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(PendingNativeRead.prototype);
        obj.__wbg_ptr = ptr;
        PendingNativeReadFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        PendingNativeReadFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_pendingnativeread_free(ptr, 0);
    }
    cancel() {
        wasm.pendingnativeread_cancel(this.__wbg_ptr);
    }
    /**
     * @returns {any}
     */
    poll() {
        const ret = wasm.pendingnativeread_poll(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
if (Symbol.dispose) PendingNativeRead.prototype[Symbol.dispose] = PendingNativeRead.prototype.free;

/**
 * A large value uploaded in chunks, then published as one row mutation.
 */
export class StreamingMutation {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(StreamingMutation.prototype);
        obj.__wbg_ptr = ptr;
        StreamingMutationFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        StreamingMutationFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_streamingmutation_free(ptr, 0);
    }
    /**
     * @returns {Promise<any>}
     */
    abort() {
        const ret = wasm.wasmstreamingmutation_abort(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {Promise<any>}
     */
    finish() {
        const ret = wasm.wasmstreamingmutation_finish(this.__wbg_ptr);
        return ret;
    }
    /**
     * Stage the value's row mutation in the transaction it began in.
     */
    finishInTransaction() {
        const ret = wasm.wasmstreamingmutation_finishInTransaction(this.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {Uint8Array} chunk
     * @returns {Promise<any>}
     */
    push(chunk) {
        const ptr0 = passArray8ToWasm0(chunk, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmstreamingmutation_push(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
}
if (Symbol.dispose) StreamingMutation.prototype[Symbol.dispose] = StreamingMutation.prototype.free;

/**
 * The shared upstream link machine (`jazz::link`), which decides when the
 * runtime's WebSocket connects, backs off and reports an outage. The runtime
 * owns the socket and the timer and steps the machine with JSON documents.
 */
export class UpstreamLink {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(UpstreamLink.prototype);
        obj.__wbg_ptr = ptr;
        UpstreamLinkFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        UpstreamLinkFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_upstreamlink_free(ptr, 0);
    }
    /**
     * Apply one input observed at `now_ms`; returns the actions, events and
     * status as JSON.
     * @param {number} now_ms
     * @param {string} input
     * @returns {string}
     */
    handle(now_ms, input) {
        let deferred3_0;
        let deferred3_1;
        try {
            const ptr0 = passStringToWasm0(input, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ret = wasm.upstreamlink_handle(this.__wbg_ptr, now_ms, ptr0, len0);
            var ptr2 = ret[0];
            var len2 = ret[1];
            if (ret[3]) {
                ptr2 = 0; len2 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred3_0 = ptr2;
            deferred3_1 = len2;
            return getStringFromWasm0(ptr2, len2);
        } finally {
            wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
        }
    }
    /**
     * `seed` drives the retry jitter.
     * @param {number} seed
     */
    constructor(seed) {
        const ret = wasm.upstreamlink_new(seed);
        this.__wbg_ptr = ret >>> 0;
        UpstreamLinkFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
}
if (Symbol.dispose) UpstreamLink.prototype[Symbol.dispose] = UpstreamLink.prototype.free;

export class WasmDb {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(WasmDb.prototype);
        obj.__wbg_ptr = ptr;
        WasmDbFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WasmDbFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_wasmdb_free(ptr, 0);
    }
    /**
     * Serve a subscriber (a tab's in-memory database) as `identity`.
     * @param {Uint8Array} identity
     * @param {any} claims
     * @param {bigint | null} [_local_epoch]
     * @returns {Promise<any>}
     */
    acceptSubscriber(identity, claims, _local_epoch) {
        const ptr0 = passArray8ToWasm0(identity, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_acceptSubscriber(this.__wbg_ptr, ptr0, len0, claims, !isLikeNone(_local_epoch), isLikeNone(_local_epoch) ? BigInt(0) : _local_epoch);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Attach a browser-local follower for a verified first-party identity.
     *
     * This is deliberately separate from [`Self::accept_subscriber`]: raw
     * serialized identities must keep rejecting Jazz-reserved issuers, while
     * a local-first or anonymous browser worker can prove its own identity
     * with the same signed capability that opened the worker database.
     * @param {any} claims
     * @param {string} token
     * @param {string} app_id
     * @param {string} claimed_author
     * @param {bigint | null} [_local_epoch]
     * @returns {Promise<any>}
     */
    acceptSubscriberWithSelfSignedProof(claims, token, app_id, claimed_author, _local_epoch) {
        const ptr0 = passStringToWasm0(token, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(app_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(claimed_author, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_acceptSubscriberWithSelfSignedProof(this.__wbg_ptr, claims, ptr0, len0, ptr1, len1, ptr2, len2, !isLikeNone(_local_epoch), isLikeNone(_local_epoch) ? BigInt(0) : _local_epoch);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {Uint8Array} query
     * @param {any} opts
     * @param {string | null | undefined} open_transaction_id
     * @param {Uint8Array | null | undefined} author
     * @param {any} claims
     * @returns {any}
     */
    all(query, opts, open_transaction_id, author, claims) {
        const ptr0 = passArray8ToWasm0(query, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(open_transaction_id) ? 0 : passStringToWasm0(open_transaction_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        var ptr2 = isLikeNone(author) ? 0 : passArray8ToWasm0(author, wasm.__wbindgen_malloc);
        var len2 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_all(this.__wbg_ptr, ptr0, len0, opts, ptr1, len1, ptr2, len2, claims);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {string} table
     * @param {Uint8Array} row_id
     * @param {Uint8Array} cells
     * @param {string} column
     * @param {string | null} [mutation]
     * @param {Uint8Array | null} [author]
     * @param {Uint8Array | null} [attribution]
     * @param {number | null} [updated_at_ms]
     * @param {any | null} [head]
     * @param {any | null} [base]
     * @param {string | null} [transaction]
     * @returns {StreamingMutation}
     */
    beginStreamingMutation(table, row_id, cells, column, mutation, author, attribution, updated_at_ms, head, base, transaction) {
        const ptr0 = passStringToWasm0(table, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArray8ToWasm0(row_id, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passArray8ToWasm0(cells, wasm.__wbindgen_malloc);
        const len2 = WASM_VECTOR_LEN;
        const ptr3 = passStringToWasm0(column, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len3 = WASM_VECTOR_LEN;
        var ptr4 = isLikeNone(mutation) ? 0 : passStringToWasm0(mutation, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len4 = WASM_VECTOR_LEN;
        var ptr5 = isLikeNone(author) ? 0 : passArray8ToWasm0(author, wasm.__wbindgen_malloc);
        var len5 = WASM_VECTOR_LEN;
        var ptr6 = isLikeNone(attribution) ? 0 : passArray8ToWasm0(attribution, wasm.__wbindgen_malloc);
        var len6 = WASM_VECTOR_LEN;
        var ptr7 = isLikeNone(transaction) ? 0 : passStringToWasm0(transaction, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len7 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_beginStreamingMutation(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3, ptr4, len4, ptr5, len5, ptr6, len6, !isLikeNone(updated_at_ms), isLikeNone(updated_at_ms) ? 0 : updated_at_ms, isLikeNone(head) ? 0 : addToExternrefTable0(head), isLikeNone(base) ? 0 : addToExternrefTable0(base), ptr7, len7);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return StreamingMutation.__wrap(ret[0]);
    }
    /**
     * Begin one owner-wide transaction.
     * @param {string} open_transaction_id
     * @param {string} kind
     * @param {Uint8Array | null} [author]
     * @param {Uint8Array | null} [attribution]
     */
    beginTransaction(open_transaction_id, kind, author, attribution) {
        const ptr0 = passStringToWasm0(open_transaction_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(kind, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        var ptr2 = isLikeNone(author) ? 0 : passArray8ToWasm0(author, wasm.__wbindgen_malloc);
        var len2 = WASM_VECTOR_LEN;
        var ptr3 = isLikeNone(attribution) ? 0 : passArray8ToWasm0(attribution, wasm.__wbindgen_malloc);
        var len3 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_beginTransaction(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * A replica's own policy evidence may be incomplete, so it never
     * decides locally; ask the authority with `requestInsertPermissionAdvice`.
     * @param {string} _table
     * @param {Uint8Array} _cells
     * @returns {string}
     */
    canInsert(_table, _cells) {
        let deferred4_0;
        let deferred4_1;
        try {
            const ptr0 = passStringToWasm0(_table, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len0 = WASM_VECTOR_LEN;
            const ptr1 = passArray8ToWasm0(_cells, wasm.__wbindgen_malloc);
            const len1 = WASM_VECTOR_LEN;
            const ret = wasm.wasmdb_canInsert(this.__wbg_ptr, ptr0, len0, ptr1, len1);
            var ptr3 = ret[0];
            var len3 = ret[1];
            if (ret[3]) {
                ptr3 = 0; len3 = 0;
                throw takeFromExternrefTable0(ret[2]);
            }
            deferred4_0 = ptr3;
            deferred4_1 = len3;
            return getStringFromWasm0(ptr3, len3);
        } finally {
            wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
        }
    }
    /**
     * @returns {any}
     */
    captureSnapshot() {
        const ret = wasm.wasmdb_captureSnapshot(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {Promise<any>}
     */
    close() {
        const ret = wasm.wasmdb_close(this.__wbg_ptr);
        return ret;
    }
    /**
     * Commit an owner-wide transaction by id.
     * @param {string} open_transaction_id
     * @param {string | null} [kind]
     * @returns {WasmWrite}
     */
    commitTransaction(open_transaction_id, kind) {
        const ptr0 = passStringToWasm0(open_transaction_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(kind) ? 0 : passStringToWasm0(kind, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len1 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_commitTransaction(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmWrite.__wrap(ret[0]);
    }
    /**
     * Connect to the server over byte frames the host carries: each frame
     * is one postcard `SyncMessage`.
     * @returns {Promise<any>}
     */
    connectUpstream() {
        const ret = wasm.wasmdb_connectUpstream(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Connect after the carrier accepted the server Hello. Negotiated
     * features must be compiled in; the rest of the session context
     * (authority endpoints, epochs) has no counterpart on SQLite's sync, so
     * this is otherwise [`Self::connect_upstream`].
     * @param {number} _protocol_version
     * @param {number} features
     * @param {Uint8Array} remote_node
     * @param {bigint} _remote_epoch
     * @param {Uint8Array} local_node
     * @param {bigint} _local_epoch
     * @returns {Promise<any>}
     */
    connectUpstreamWithSession(_protocol_version, features, remote_node, _remote_epoch, local_node, _local_epoch) {
        const ptr0 = passArray8ToWasm0(remote_node, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArray8ToWasm0(local_node, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_connectUpstreamWithSession(this.__wbg_ptr, _protocol_version, features, ptr0, len0, _remote_epoch, ptr1, len1, _local_epoch);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * A fresh upstream link machine for this runtime's server connection;
     * `seed` drives its retry jitter.
     * @param {number} seed
     * @returns {UpstreamLink}
     */
    createUpstreamLink(seed) {
        const ret = wasm.wasmdb_createUpstreamLink(this.__wbg_ptr, seed);
        return UpstreamLink.__wrap(ret);
    }
    /**
     * @param {string} table
     * @param {Uint8Array} row_id
     * @param {any} options
     * @returns {WasmWrite}
     */
    delete(table, row_id, options) {
        const ptr0 = passStringToWasm0(table, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArray8ToWasm0(row_id, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_delete(this.__wbg_ptr, ptr0, len0, ptr1, len1, options);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmWrite.__wrap(ret[0]);
    }
    /**
     * @param {string} open_transaction_id
     * @param {string} table
     * @param {Uint8Array} row_id
     * @param {any} options
     */
    deleteInTransaction(open_transaction_id, table, row_id, options) {
        const ptr0 = passStringToWasm0(open_transaction_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(table, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passArray8ToWasm0(row_id, wasm.__wbindgen_malloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_deleteInTransaction(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2, options);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Delete a durable browser store (`{ backend, path }`, as for
     * `openBrowser`). No database may have it open.
     * @param {any} storage
     * @param {string} database
     * @returns {Promise<void>}
     */
    static destroyBrowserStorage(storage, database) {
        const ptr0 = passStringToWasm0(database, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_destroyBrowserStorage(storage, ptr0, len0);
        return ret;
    }
    /**
     * Run one idempotent expiry pass; browser hosts normally call this from a timer.
     * @returns {Promise<any>}
     */
    evictExpiredStagedLargeValues() {
        const ret = wasm.wasmdb_evictExpiredStagedLargeValues(this.__wbg_ptr);
        return ret;
    }
    /**
     * Wait until every commit so far is in the browser store's backing
     * storage. A no-op for in-memory databases.
     * @returns {Promise<any>}
     */
    flush() {
        const ret = wasm.wasmdb_flush(this.__wbg_ptr);
        return ret;
    }
    /**
     * The newest transaction time this database handed out under its
     * node (a `TxTime` is the commit seq). A leased node's next holder
     * seeds it through `seedForegroundTxTimeHighWater`.
     * @returns {Promise<any>}
     */
    foregroundTxTimeHighWater() {
        const ret = wasm.wasmdb_foregroundTxTimeHighWater(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {string} table
     * @param {Uint8Array} cells
     * @param {any} options
     * @returns {WasmWrite}
     */
    insert(table, cells, options) {
        const ptr0 = passStringToWasm0(table, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArray8ToWasm0(cells, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_insert(this.__wbg_ptr, ptr0, len0, ptr1, len1, options);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmWrite.__wrap(ret[0]);
    }
    /**
     * @param {string} open_transaction_id
     * @param {string} table
     * @param {Uint8Array} cells
     * @param {any} options
     * @returns {Uint8Array}
     */
    insertInTransaction(open_transaction_id, table, cells, options) {
        const ptr0 = passStringToWasm0(open_transaction_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(table, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passArray8ToWasm0(cells, wasm.__wbindgen_malloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_insertInTransaction(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2, options);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v4 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v4;
    }
    /**
     * Exact local state for the write-merge bridge: the row as stored,
     * deleted or not. Write authorization remains at the mutation boundary;
     * this is not a query.
     * @param {string} table
     * @param {Uint8Array} row_id
     * @returns {Uint8Array}
     */
    localCurrentRow(table, row_id) {
        const ptr0 = passStringToWasm0(table, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArray8ToWasm0(row_id, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_localCurrentRow(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v3 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v3;
    }
    /**
     * Register a callback for rejected writes that no active wait consumed.
     * @param {Function} callback
     */
    onMutationError(callback) {
        wasm.wasmdb_onMutationError(this.__wbg_ptr, callback);
    }
    /**
     * Register `callback(message)`, called when writing the browser store
     * to its backing storage starts failing (storage full, most often)
     * and `callback(null)` once a write succeeds again. Meanwhile commits
     * stay in memory, tabs do not hear their writes are `Local`, and
     * `flush` fails with code `storage`. Called at once if failing now.
     * @param {Function} callback
     */
    onStorageFailure(callback) {
        wasm.wasmdb_onStorageFailure(this.__wbg_ptr, callback);
    }
    /**
     * Open the durable store a browser worker owns. `storage` selects the
     * file: `{ backend?: "indexeddb", path?: string }` (see [`browser`]).
     * The default file is named after `database`, the physical database
     * name the worker admitted.
     * @param {any} storage
     * @param {Uint8Array} schema
     * @param {Uint8Array} config
     * @param {string} database
     * @returns {Promise<WasmDb>}
     */
    static openBrowser(storage, schema, config, database) {
        const ptr0 = passArray8ToWasm0(schema, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArray8ToWasm0(config, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(database, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_openBrowser(storage, ptr0, len0, ptr1, len1, ptr2, len2);
        return ret;
    }
    /**
     * @param {any} storage
     * @param {Uint8Array} schema
     * @param {Uint8Array} config
     * @param {string} token
     * @param {string} app_id
     * @param {string} claimed_author
     * @param {string} database
     * @returns {Promise<WasmDb>}
     */
    static openBrowserWithSelfSignedProof(storage, schema, config, token, app_id, claimed_author, database) {
        const ptr0 = passArray8ToWasm0(schema, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArray8ToWasm0(config, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(token, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ptr3 = passStringToWasm0(app_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len3 = WASM_VECTOR_LEN;
        const ptr4 = passStringToWasm0(claimed_author, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len4 = WASM_VECTOR_LEN;
        const ptr5 = passStringToWasm0(database, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len5 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_openBrowserWithSelfSignedProof(storage, ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3, ptr4, len4, ptr5, len5);
        return ret;
    }
    /**
     * @param {Uint8Array} schema
     * @param {Uint8Array} config
     * @returns {WasmDb}
     */
    static openMemory(schema, config) {
        const ptr0 = passArray8ToWasm0(schema, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArray8ToWasm0(config, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_openMemory(ptr0, len0, ptr1, len1);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmDb.__wrap(ret[0]);
    }
    /**
     * Open a deliberate backend runtime. This remains a separate ABI from
     * `openMemory`: the public raw-open configuration can never select the
     * privileged system author.
     * @param {Uint8Array} schema
     * @param {Uint8Array} config
     * @returns {WasmDb}
     */
    static openMemoryAsBackend(schema, config) {
        const ptr0 = passArray8ToWasm0(schema, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArray8ToWasm0(config, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_openMemoryAsBackend(ptr0, len0, ptr1, len1);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmDb.__wrap(ret[0]);
    }
    /**
     * Open with a verified Jazz self-signed client identity. This deliberately
     * stays separate from `openMemory`: untrusted open config bytes can never
     * select a Jazz-reserved identity.
     * @param {Uint8Array} schema
     * @param {Uint8Array} config
     * @param {string} token
     * @param {string} app_id
     * @param {string} claimed_author
     * @returns {WasmDb}
     */
    static openMemoryWithSelfSignedProof(schema, config, token, app_id, claimed_author) {
        const ptr0 = passArray8ToWasm0(schema, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArray8ToWasm0(config, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passStringToWasm0(token, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len2 = WASM_VECTOR_LEN;
        const ptr3 = passStringToWasm0(app_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len3 = WASM_VECTOR_LEN;
        const ptr4 = passStringToWasm0(claimed_author, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len4 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_openMemoryWithSelfSignedProof(ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3, ptr4, len4);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmDb.__wrap(ret[0]);
    }
    /**
     * Register a typed schema view backed by this same runtime owner, of
     * an app shipping `migrations` (its bundle as JSON).
     * @param {Uint8Array} schema
     * @param {Uint8Array | null} [migrations]
     * @returns {WasmDb}
     */
    registerSchema(schema, migrations) {
        const ptr0 = passArray8ToWasm0(schema, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(migrations) ? 0 : passArray8ToWasm0(migrations, wasm.__wbindgen_malloc);
        var len1 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_registerSchema(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmDb.__wrap(ret[0]);
    }
    /**
     * @param {string} table
     * @param {Uint8Array} row_id
     * @returns {WasmPermissionAdviceRequest}
     */
    requestDeletePermissionAdvice(table, row_id) {
        const ptr0 = passStringToWasm0(table, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArray8ToWasm0(row_id, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_requestDeletePermissionAdvice(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmPermissionAdviceRequest.__wrap(ret[0]);
    }
    /**
     * @param {string} table
     * @param {Uint8Array} cells
     * @returns {WasmPermissionAdviceRequest}
     */
    requestInsertPermissionAdvice(table, cells) {
        const ptr0 = passStringToWasm0(table, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArray8ToWasm0(cells, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_requestInsertPermissionAdvice(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmPermissionAdviceRequest.__wrap(ret[0]);
    }
    /**
     * @param {string} table
     * @param {Uint8Array} row_id
     * @returns {WasmPermissionAdviceRequest}
     */
    requestReadPermissionAdvice(table, row_id) {
        const ptr0 = passStringToWasm0(table, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArray8ToWasm0(row_id, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_requestReadPermissionAdvice(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmPermissionAdviceRequest.__wrap(ret[0]);
    }
    /**
     * @param {string} table
     * @param {Uint8Array} row_id
     * @param {Uint8Array} patch
     * @returns {WasmPermissionAdviceRequest}
     */
    requestUpdatePermissionAdvice(table, row_id, patch) {
        const ptr0 = passStringToWasm0(table, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArray8ToWasm0(row_id, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passArray8ToWasm0(patch, wasm.__wbindgen_malloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_requestUpdatePermissionAdvice(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmPermissionAdviceRequest.__wrap(ret[0]);
    }
    /**
     * @param {string} table
     * @param {Uint8Array} row_id
     * @param {Uint8Array | null | undefined} cells
     * @param {any} options
     * @returns {WasmWrite}
     */
    restore(table, row_id, cells, options) {
        const ptr0 = passStringToWasm0(table, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArray8ToWasm0(row_id, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        var ptr2 = isLikeNone(cells) ? 0 : passArray8ToWasm0(cells, wasm.__wbindgen_malloc);
        var len2 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_restore(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2, options);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmWrite.__wrap(ret[0]);
    }
    /**
     * @param {string} open_transaction_id
     * @param {string} table
     * @param {Uint8Array} row_id
     * @param {Uint8Array | null | undefined} cells
     * @param {any} options
     */
    restoreInTransaction(open_transaction_id, table, row_id, cells, options) {
        const ptr0 = passStringToWasm0(open_transaction_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(table, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passArray8ToWasm0(row_id, wasm.__wbindgen_malloc);
        const len2 = WASM_VECTOR_LEN;
        var ptr3 = isLikeNone(cells) ? 0 : passArray8ToWasm0(cells, wasm.__wbindgen_malloc);
        var len3 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_restoreInTransaction(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3, options);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Roll back an owner-wide open transaction by id.
     * @param {string} open_transaction_id
     */
    rollbackTransaction(open_transaction_id) {
        const ptr0 = passStringToWasm0(open_transaction_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_rollbackTransaction(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Continue after a previous holder of this node: no transaction time
     * at or below `high_water` is reused.
     * @param {bigint} high_water
     */
    seedForegroundTxTimeHighWater(high_water) {
        const ret = wasm.wasmdb_seedForegroundTxTimeHighWater(this.__wbg_ptr, high_water);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {Uint8Array} author
     * @param {any} claims
     */
    setIdentityClaims(author, claims) {
        const ptr0 = passArray8ToWasm0(author, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_setIdentityClaims(this.__wbg_ptr, ptr0, len0, claims);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Configure Jazz-owned upload ingress and unpublished-tree expiry limits.
     * @param {number} incoming_bytes_per_window
     * @param {number} window_ms
     * @param {number | null} [max_age_ms]
     */
    setLargeValueStagingPolicy(incoming_bytes_per_window, window_ms, max_age_ms) {
        const ret = wasm.wasmdb_setLargeValueStagingPolicy(this.__wbg_ptr, incoming_bytes_per_window, window_ms, !isLikeNone(max_age_ms), isLikeNone(max_age_ms) ? 0 : max_age_ms);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * The optimistic in-memory side of a browser client/worker pair: its
     * subscriptions open with the worker's answer.
     */
    setNonDurableClient() {
        const ret = wasm.wasmdb_setNonDurableClient(this.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Report what the host knows about the path to the authoritative server
     * (`"none" | "attempting" | "live" | "failed"`; the TypeScript names
     * `"connecting" | "connected" | "unavailable"` are accepted as aliases).
     * @param {string} state
     */
    setRemoteLinkHint(state) {
        const ptr0 = passStringToWasm0(state, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_setRemoteLinkHint(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Bind correlation claims to this already-open client's own identity.
     * This does not grant a different author or enable serving reads.
     * @param {any} claims
     * @returns {any}
     */
    setSessionClaims(claims) {
        const ret = wasm.wasmdb_setSessionClaims(this.__wbg_ptr, claims);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Report query runs of at least `ms` milliseconds (default 50); 0
     * turns the slow-query log off.
     * @param {number} ms
     */
    setSlowQueryThresholdMs(ms) {
        const ret = wasm.wasmdb_setSlowQueryThresholdMs(this.__wbg_ptr, ms);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * The host's tick callback: called with `"immediate"` whenever there
     * is sync work (a local write to upload, frames to apply).
     * @param {Function} callback
     */
    setTickScheduler(callback) {
        wasm.wasmdb_setTickScheduler(this.__wbg_ptr, callback);
    }
    /**
     * @param {Uint8Array} query
     * @param {any} opts
     * @param {Uint8Array | null | undefined} author
     * @param {any} claims
     * @returns {any}
     */
    subscribe(query, opts, author, claims) {
        const ptr0 = passArray8ToWasm0(query, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        var ptr1 = isLikeNone(author) ? 0 : passArray8ToWasm0(author, wasm.__wbindgen_malloc);
        var len1 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_subscribe(this.__wbg_ptr, ptr0, len0, opts, ptr1, len1, claims);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * The slow-query report due now: one line per slow query shape,
     * naming `app`: the first at once, then at most every 10 seconds. The caller
     * writes each line with `console.warn`.
     * @param {string | null} [app]
     * @returns {string[]}
     */
    takeSlowQueryReport(app) {
        var ptr0 = isLikeNone(app) ? 0 : passStringToWasm0(app, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_takeSlowQueryReport(this.__wbg_ptr, ptr0, len0);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        var v2 = getArrayJsValueFromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
        return v2;
    }
    /**
     * @returns {Promise<any>}
     */
    tick() {
        const ret = wasm.wasmdb_tick(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {string} table
     * @param {Uint8Array} row_id
     * @param {Uint8Array} patch
     * @param {any} options
     * @returns {WasmWrite}
     */
    update(table, row_id, patch, options) {
        const ptr0 = passStringToWasm0(table, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArray8ToWasm0(row_id, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passArray8ToWasm0(patch, wasm.__wbindgen_malloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_update(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2, options);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmWrite.__wrap(ret[0]);
    }
    /**
     * @param {string} open_transaction_id
     * @param {string} table
     * @param {Uint8Array} row_id
     * @param {Uint8Array} patch
     * @param {any} options
     */
    updateInTransaction(open_transaction_id, table, row_id, patch, options) {
        const ptr0 = passStringToWasm0(open_transaction_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(table, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passArray8ToWasm0(row_id, wasm.__wbindgen_malloc);
        const len2 = WASM_VECTOR_LEN;
        const ptr3 = passArray8ToWasm0(patch, wasm.__wbindgen_malloc);
        const len3 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_updateInTransaction(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3, options);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * @param {string} table
     * @param {Uint8Array} row_id
     * @param {Uint8Array} patch
     * @param {any} mutations
     * @param {number | null} [updated_at_ms]
     * @returns {WasmWrite}
     */
    updateLargeValues(table, row_id, patch, mutations, updated_at_ms) {
        const ptr0 = passStringToWasm0(table, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArray8ToWasm0(row_id, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passArray8ToWasm0(patch, wasm.__wbindgen_malloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_updateLargeValues(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2, mutations, !isLikeNone(updated_at_ms), isLikeNone(updated_at_ms) ? 0 : updated_at_ms);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmWrite.__wrap(ret[0]);
    }
    /**
     * Typed partial-value updates staged inside an open transaction.
     * @param {string} open_transaction_id
     * @param {string} table
     * @param {Uint8Array} row_id
     * @param {Uint8Array} patch
     * @param {any} mutations
     * @param {number | null} [updated_at_ms]
     */
    updateLargeValuesInTransaction(open_transaction_id, table, row_id, patch, mutations, updated_at_ms) {
        const ptr0 = passStringToWasm0(open_transaction_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(table, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passArray8ToWasm0(row_id, wasm.__wbindgen_malloc);
        const len2 = WASM_VECTOR_LEN;
        const ptr3 = passArray8ToWasm0(patch, wasm.__wbindgen_malloc);
        const len3 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_updateLargeValuesInTransaction(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3, mutations, !isLikeNone(updated_at_ms), isLikeNone(updated_at_ms) ? 0 : updated_at_ms);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * This store's uploads: how many still wait for the server's verdict
     * and since when, and what the server refused since it opened
     * (`{ pending, oldestPendingAt, rejected, lastRejection }`).
     * @returns {any}
     */
    uploadStatus() {
        const ret = wasm.wasmdb_uploadStatus(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {string} table
     * @param {Uint8Array} row_id
     * @param {Uint8Array} cells
     * @param {any} options
     * @returns {WasmWrite}
     */
    upsert(table, row_id, cells, options) {
        const ptr0 = passStringToWasm0(table, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passArray8ToWasm0(row_id, wasm.__wbindgen_malloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passArray8ToWasm0(cells, wasm.__wbindgen_malloc);
        const len2 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_upsert(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2, options);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return WasmWrite.__wrap(ret[0]);
    }
    /**
     * @param {string} open_transaction_id
     * @param {string} table
     * @param {Uint8Array} row_id
     * @param {Uint8Array} cells
     * @param {any} options
     */
    upsertInTransaction(open_transaction_id, table, row_id, cells, options) {
        const ptr0 = passStringToWasm0(open_transaction_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(table, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ptr2 = passArray8ToWasm0(row_id, wasm.__wbindgen_malloc);
        const len2 = WASM_VECTOR_LEN;
        const ptr3 = passArray8ToWasm0(cells, wasm.__wbindgen_malloc);
        const len3 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_upsertInTransaction(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3, options);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Resolve once every local write so far reached `tier`. Settling
     * `cancelled` stops a wait that is still pending and rejects it, so a
     * caller that gives up does not leave the core waiter parked.
     * @param {string} tier
     * @param {Promise<any> | null} [cancelled]
     * @returns {Promise<any>}
     */
    waitForPendingWrites(tier, cancelled) {
        const ptr0 = passStringToWasm0(tier, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmdb_waitForPendingWrites(this.__wbg_ptr, ptr0, len0, isLikeNone(cancelled) ? 0 : addToExternrefTable0(cancelled));
        return ret;
    }
    /**
     * Exact wire capabilities compiled into this WASM artifact.
     * @returns {number}
     */
    wireFeatures() {
        const ret = wasm.wasmdb_wireFeatures(this.__wbg_ptr);
        return ret >>> 0;
    }
}
if (Symbol.dispose) WasmDb.prototype[Symbol.dispose] = WasmDb.prototype.free;

export class WasmPendingSubscription {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WasmPendingSubscriptionFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_wasmpendingsubscription_free(ptr, 0);
    }
    cancel() {
        wasm.wasmpendingsubscription_cancel(this.__wbg_ptr);
    }
    /**
     * @returns {any | undefined}
     */
    poll() {
        const ret = wasm.wasmpendingsubscription_poll(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @param {Function} callback
     */
    setWake(callback) {
        wasm.wasmpendingsubscription_setWake(this.__wbg_ptr, callback);
    }
}
if (Symbol.dispose) WasmPendingSubscription.prototype[Symbol.dispose] = WasmPendingSubscription.prototype.free;

/**
 * One permission preflight sent to the upstream authority.
 * One permission preflight sent to the upstream authority.
 */
export class WasmPermissionAdviceRequest {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(WasmPermissionAdviceRequest.prototype);
        obj.__wbg_ptr = ptr;
        WasmPermissionAdviceRequestFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WasmPermissionAdviceRequestFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_wasmpermissionadvicerequest_free(ptr, 0);
    }
    /**
     * Resolve the promise as `"unknown"`; a late answer is ignored.
     */
    cancel() {
        wasm.wasmpermissionadvicerequest_cancel(this.__wbg_ptr);
    }
    /**
     * @returns {Promise<any>}
     */
    get promise() {
        const ret = wasm.wasmpermissionadvicerequest_promise(this.__wbg_ptr);
        return ret;
    }
}
if (Symbol.dispose) WasmPermissionAdviceRequest.prototype[Symbol.dispose] = WasmPermissionAdviceRequest.prototype.free;

/**
 * One sync link, carried by the host as byte frames. Frames are applied
 * and produced by the database's tick.
 */
export class WasmTransport {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(WasmTransport.prototype);
        obj.__wbg_ptr = ptr;
        WasmTransportFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WasmTransportFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_wasmtransport_free(ptr, 0);
    }
    /**
     * Never resolves: there is no auxiliary lane to produce output.
     * @returns {Promise<any>}
     */
    auxiliaryOutboundReady() {
        const ret = wasm.wasmtransport_auxiliaryOutboundReady(this.__wbg_ptr);
        return ret;
    }
    /**
     * @returns {number | undefined}
     */
    auxiliaryReceiveTimeoutMs() {
        const ret = wasm.wasmtransport_auxiliaryReceiveTimeoutMs(this.__wbg_ptr);
        return ret === 0x100000001 ? undefined : ret;
    }
    clearOutboundScheduler() {
        wasm.wasmtransport_clearOutboundScheduler(this.__wbg_ptr);
    }
    /**
     * @returns {boolean}
     */
    close() {
        const ret = wasm.wasmtransport_close(this.__wbg_ptr);
        return ret !== 0;
    }
    expireAuxiliaryReceive() {
        wasm.wasmtransport_expireAuxiliaryReceive(this.__wbg_ptr);
    }
    /**
     * @param {number | null} [_max_frames]
     * @param {number | null} [_max_bytes]
     * @returns {Array<any>}
     */
    recvAuxiliaryWireFrames(_max_frames, _max_bytes) {
        const ret = wasm.wasmtransport_recvAuxiliaryWireFrames(this.__wbg_ptr, isLikeNone(_max_frames) ? 0x100000001 : (_max_frames) >>> 0, isLikeNone(_max_bytes) ? 0x100000001 : (_max_bytes) >>> 0);
        return ret;
    }
    /**
     * @returns {Array<any>}
     */
    recvWireFrames() {
        const ret = wasm.wasmtransport_recvWireFrames(this.__wbg_ptr);
        return ret;
    }
    /**
     * SQLite's sync has no auxiliary chunk lane: large-value chunks travel
     * as ordinary sync messages. Every frame belongs to the ordinary lane.
     * @param {Uint8Array} frame
     * @returns {Promise<any>}
     */
    routeAuxiliaryWireFrame(frame) {
        const ptr0 = passArray8ToWasm0(frame, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmtransport_routeAuxiliaryWireFrame(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * @param {Uint8Array} frame
     */
    sendWireFrame(frame) {
        const ptr0 = passArray8ToWasm0(frame, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        wasm.wasmtransport_sendWireFrame(this.__wbg_ptr, ptr0, len0);
    }
    /**
     * @param {Array<any>} frames
     */
    sendWireFrames(frames) {
        wasm.wasmtransport_sendWireFrames(this.__wbg_ptr, frames);
    }
    /**
     * @param {boolean} _enabled
     */
    setAuxiliaryTraceEnabled(_enabled) {
        wasm.wasmtransport_setAuxiliaryTraceEnabled(this.__wbg_ptr, _enabled);
    }
    /**
     * @param {Function} callback
     */
    setOutboundScheduler(callback) {
        wasm.wasmtransport_setOutboundScheduler(this.__wbg_ptr, callback);
    }
    /**
     * @returns {Array<any>}
     */
    takeAuxiliaryTrace() {
        const ret = wasm.wasmtransport_takeAuxiliaryTrace(this.__wbg_ptr);
        return ret;
    }
    /**
     * Tick the database this link belongs to: apply received frames, send
     * what is due. Resolves with the number of frames still to send.
     * @returns {Promise<any>}
     */
    tick() {
        const ret = wasm.wasmtransport_tick(this.__wbg_ptr);
        return ret;
    }
    /**
     * @param {any} claims
     * @returns {Promise<any>}
     */
    updateAuthenticatedClaims(claims) {
        const ret = wasm.wasmtransport_updateAuthenticatedClaims(this.__wbg_ptr, claims);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Why the database dropped this upstream link on its own, as an
     * `Error` with the core's stable `code` (`authority_changed` for a
     * server whose store was recreated), or `null` while the link stands.
     * The host stops the link with it rather than retry.
     * @returns {any}
     */
    upstreamRefusal() {
        const ret = wasm.wasmtransport_upstreamRefusal(this.__wbg_ptr);
        return ret;
    }
}
if (Symbol.dispose) WasmTransport.prototype[Symbol.dispose] = WasmTransport.prototype.free;

export class WasmWrite {
    static __wrap(ptr) {
        ptr = ptr >>> 0;
        const obj = Object.create(WasmWrite.prototype);
        obj.__wbg_ptr = ptr;
        WasmWriteFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        WasmWriteFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_wasmwrite_free(ptr, 0);
    }
    /**
     * @returns {boolean}
     */
    close() {
        const ret = wasm.wasmwrite_close(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * @returns {Uint8Array}
     */
    get payload() {
        const ret = wasm.wasmwrite_payload(this.__wbg_ptr);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * @returns {Uint8Array}
     */
    get rowId() {
        const ret = wasm.wasmwrite_rowId(this.__wbg_ptr);
        var v1 = getArrayU8FromWasm0(ret[0], ret[1]).slice();
        wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        return v1;
    }
    /**
     * @returns {string}
     */
    get txId() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.wasmwrite_txId(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Resolve once the write reached `tier`: at once for `none` and
     * `local` (the commit is in the store when the write call returns), on
     * the server's acceptance for `global`, rejecting if it refused.
     * @param {string} tier
     * @param {boolean | null} [observe_only]
     * @returns {Promise<any>}
     */
    wait(tier, observe_only) {
        const ptr0 = passStringToWasm0(tier, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.wasmwrite_wait(this.__wbg_ptr, ptr0, len0, isLikeNone(observe_only) ? 0xFFFFFF : observe_only ? 1 : 0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * @returns {any}
     */
    writeState() {
        const ret = wasm.wasmwrite_writeState(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
if (Symbol.dispose) WasmWrite.prototype[Symbol.dispose] = WasmWrite.prototype.free;

/**
 * Test-only bridge for executing the Rust-owned v1 binding corpus through the
 * generated WASM artifact. The JavaScript test still uses the production
 * decoder for every returned postcard payload.
 * @returns {string}
 */
export function __testBindingCodecGoldenFixture() {
    let deferred1_0;
    let deferred1_1;
    try {
        const ret = wasm.__testBindingCodecGoldenFixture();
        deferred1_0 = ret[0];
        deferred1_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
    }
}

/**
 * Test-only: read one pinned wire corpus batch through the generated WASM
 * artifact, as `reader` (`"server-opening"`, `"server"` or `"client"`)
 * would, with the production frame and sync message decoders. Not a
 * browser transport API.
 * @param {Uint8Array} batch
 * @param {string} reader
 * @param {string} negotiated_features
 */
export function __testValidateWireFrameBatchCorpus(batch, reader, negotiated_features) {
    const ptr0 = passArray8ToWasm0(batch, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ptr1 = passStringToWasm0(reader, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len1 = WASM_VECTOR_LEN;
    const ptr2 = passStringToWasm0(negotiated_features, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len2 = WASM_VECTOR_LEN;
    const ret = wasm.__testValidateWireFrameBatchCorpus(ptr0, len0, ptr1, len1, ptr2, len2);
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}

/**
 * Test-only feature inventory paired with [`test_validate_wire_frame_batch_corpus`].
 * @returns {string}
 */
export function __testWireFrameCorpusFeatures() {
    let deferred1_0;
    let deferred1_1;
    try {
        const ret = wasm.__testWireFrameCorpusFeatures();
        deferred1_0 = ret[0];
        deferred1_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
    }
}

/**
 * The anchor at `position` (UTF-16 code units) of `text`.
 * @param {string} text
 * @param {number | null | undefined} version
 * @param {number} position
 * @param {any} side
 * @returns {any}
 */
export function captureTextAnchor(text, version, position, side) {
    const ptr0 = passStringToWasm0(text, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.captureTextAnchor(ptr0, len0, !isLikeNone(version), isLikeNone(version) ? 0 : version, position, side);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * The range `start..end` (UTF-16 code units) of `text`.
 * @param {string} text
 * @param {number | null | undefined} version
 * @param {number} start
 * @param {number} end
 * @returns {any}
 */
export function captureTextRange(text, version, start, end) {
    const ptr0 = passStringToWasm0(text, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.captureTextRange(ptr0, len0, !isLikeNone(version), isLikeNone(version) ? 0 : version, start, end);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Get the current timestamp in milliseconds since Unix epoch.
 * @returns {bigint}
 */
export function currentTimestamp() {
    const ret = wasm.currentTimestamp();
    return BigInt.asUintN(64, ret);
}

/**
 * Derive a stable local-first user id from a base64url-encoded 32-byte seed.
 * @param {string} seed_b64
 * @returns {string}
 */
export function deriveUserId(seed_b64) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passStringToWasm0(seed_b64, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.deriveUserId(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Drain buffered tracing entries as a JavaScript array.
 * @returns {any}
 */
export function drainTraceEntries() {
    const ret = wasm.drainTraceEntries();
    return ret;
}

/**
 * Generate a new UUID v7 (time-ordered).
 *
 * Useful when a caller wants the default generated row-id shape.
 * @returns {string}
 */
export function generateId() {
    let deferred1_0;
    let deferred1_1;
    try {
        const ret = wasm.generateId();
        deferred1_0 = ret[0];
        deferred1_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
    }
}

/**
 * Initialize the WASM module.
 *
 * Sets up the panic hook for better error messages in the browser console.
 * Tracing is initialized by the first owning database open, after callers
 * have selected `globalThis.__JAZZ_WASM_LOG_LEVEL`.
 */
export function init() {
    wasm.init();
}

/**
 * Mint an anonymous identity JWT from a base64url-encoded 32-byte seed.
 * @param {string} seed_b64
 * @param {string} audience
 * @param {number} ttl_seconds
 * @param {bigint} now_seconds
 * @returns {string}
 */
export function mintAnonymousToken(seed_b64, audience, ttl_seconds, now_seconds) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(seed_b64, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(audience, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.mintAnonymousToken(ptr0, len0, ptr1, len1, ttl_seconds, now_seconds);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Mint a local-first identity JWT from a base64url-encoded 32-byte seed.
 * @param {string} seed_b64
 * @param {string} audience
 * @param {number} ttl_seconds
 * @param {bigint} now_seconds
 * @returns {string}
 */
export function mintLocalFirstToken(seed_b64, audience, ttl_seconds, now_seconds) {
    let deferred4_0;
    let deferred4_1;
    try {
        const ptr0 = passStringToWasm0(seed_b64, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ptr1 = passStringToWasm0(audience, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len1 = WASM_VECTOR_LEN;
        const ret = wasm.mintLocalFirstToken(ptr0, len0, ptr1, len1, ttl_seconds, now_seconds);
        var ptr3 = ret[0];
        var len3 = ret[1];
        if (ret[3]) {
            ptr3 = 0; len3 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred4_0 = ptr3;
        deferred4_1 = len3;
        return getStringFromWasm0(ptr3, len3);
    } finally {
        wasm.__wbindgen_free(deferred4_0, deferred4_1, 1);
    }
}

/**
 * Exact build/ABI fingerprint for this generated WASM artifact.
 * @returns {string}
 */
export function nativeArtifactFingerprint() {
    let deferred1_0;
    let deferred1_1;
    try {
        const ret = wasm.nativeArtifactFingerprint();
        deferred1_0 = ret[0];
        deferred1_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
    }
}

/**
 * Where `anchor` lands in `text`: `{ position, confidence, ambiguous }`.
 * @param {any} anchor
 * @param {string} text
 * @param {number | null} [version]
 * @returns {any}
 */
export function resolveTextAnchor(anchor, text, version) {
    const ptr0 = passStringToWasm0(text, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.resolveTextAnchor(anchor, ptr0, len0, !isLikeNone(version), isLikeNone(version) ? 0 : version);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Where `range` lands in `text`: `{ start, end, confidence, ambiguous }`.
 * @param {any} range
 * @param {string} text
 * @param {number | null} [version]
 * @returns {any}
 */
export function resolveTextRange(range, text, version) {
    const ptr0 = passStringToWasm0(text, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.resolveTextRange(range, ptr0, len0, !isLikeNone(version), isLikeNone(version) ? 0 : version);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Install the JSON Schema validator for JSON columns.
 *
 * The browser build leaves the Rust validator out to keep the binary small.
 * `compile` takes a declared schema as JSON text and returns a check that
 * takes a value as JSON text and returns why it does not match, or
 * `undefined`. `compile` throws when the schema itself is invalid; a check
 * that throws is reported as the validator failing, not as a mismatch.
 * Until this is called, JSON column schemas are reported as unavailable.
 * @param {Function} compile
 */
export function setJsonSchemaValidator(compile) {
    wasm.setJsonSchemaValidator(compile);
}

/**
 * Enable or disable buffering of tracing entries for JavaScript drains.
 * @param {boolean} enabled
 */
export function setTraceEntryCollectionEnabled(enabled) {
    wasm.setTraceEntryCollectionEnabled(enabled);
}

/**
 * Register a callback invoked when buffered tracing entries are ready.
 * Returns an unsubscribe function.
 * @param {Function} callback
 * @returns {Function}
 */
export function subscribeTraceEntries(callback) {
    const ret = wasm.subscribeTraceEntries(callback);
    return ret;
}

/**
 * Validate a schema and its embedded permissions without opening a database.
 * @param {Uint8Array} schema
 */
export function validateSchema(schema) {
    const ptr0 = passArray8ToWasm0(schema, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.validateSchema(ptr0, len0);
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}

function __wbg_get_imports() {
    const import0 = {
        __proto__: null,
        __wbg_Error_2e59b1b37a9a34c3: function(arg0, arg1) {
            const ret = Error(getStringFromWasm0(arg0, arg1));
            return ret;
        },
        __wbg_Number_e6ffdb596c888833: function(arg0) {
            const ret = Number(arg0);
            return ret;
        },
        __wbg_String_8564e559799eccda: function(arg0, arg1) {
            const ret = String(arg1);
            const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg_Window_70131fc0c91e4b3c: function(arg0) {
            const ret = arg0.Window;
            return ret;
        },
        __wbg_WorkerGlobalScope_601c48015b8cc78e: function(arg0) {
            const ret = arg0.WorkerGlobalScope;
            return ret;
        },
        __wbg___wbindgen_bigint_get_as_i64_2c5082002e4826e2: function(arg0, arg1) {
            const v = arg1;
            const ret = typeof(v) === 'bigint' ? v : undefined;
            getDataViewMemory0().setBigInt64(arg0 + 8 * 1, isLikeNone(ret) ? BigInt(0) : ret, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, !isLikeNone(ret), true);
        },
        __wbg___wbindgen_boolean_get_a86c216575a75c30: function(arg0) {
            const v = arg0;
            const ret = typeof(v) === 'boolean' ? v : undefined;
            return isLikeNone(ret) ? 0xFFFFFF : ret ? 1 : 0;
        },
        __wbg___wbindgen_debug_string_dd5d2d07ce9e6c57: function(arg0, arg1) {
            const ret = debugString(arg1);
            const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg___wbindgen_in_4bd7a57e54337366: function(arg0, arg1) {
            const ret = arg0 in arg1;
            return ret;
        },
        __wbg___wbindgen_is_bigint_6c98f7e945dacdde: function(arg0) {
            const ret = typeof(arg0) === 'bigint';
            return ret;
        },
        __wbg___wbindgen_is_function_49868bde5eb1e745: function(arg0) {
            const ret = typeof(arg0) === 'function';
            return ret;
        },
        __wbg___wbindgen_is_null_344c8750a8525473: function(arg0) {
            const ret = arg0 === null;
            return ret;
        },
        __wbg___wbindgen_is_object_40c5a80572e8f9d3: function(arg0) {
            const val = arg0;
            const ret = typeof(val) === 'object' && val !== null;
            return ret;
        },
        __wbg___wbindgen_is_string_b29b5c5a8065ba1a: function(arg0) {
            const ret = typeof(arg0) === 'string';
            return ret;
        },
        __wbg___wbindgen_is_undefined_c0cca72b82b86f4d: function(arg0) {
            const ret = arg0 === undefined;
            return ret;
        },
        __wbg___wbindgen_jsval_eq_7d430e744a913d26: function(arg0, arg1) {
            const ret = arg0 === arg1;
            return ret;
        },
        __wbg___wbindgen_jsval_loose_eq_3a72ae764d46d944: function(arg0, arg1) {
            const ret = arg0 == arg1;
            return ret;
        },
        __wbg___wbindgen_number_get_7579aab02a8a620c: function(arg0, arg1) {
            const obj = arg1;
            const ret = typeof(obj) === 'number' ? obj : undefined;
            getDataViewMemory0().setFloat64(arg0 + 8 * 1, isLikeNone(ret) ? 0 : ret, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, !isLikeNone(ret), true);
        },
        __wbg___wbindgen_string_get_914df97fcfa788f2: function(arg0, arg1) {
            const obj = arg1;
            const ret = typeof(obj) === 'string' ? obj : undefined;
            var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg___wbindgen_throw_81fc77679af83bc6: function(arg0, arg1) {
            throw new Error(getStringFromWasm0(arg0, arg1));
        },
        __wbg__wbg_cb_unref_3c3b4f651835fbcb: function(arg0) {
            arg0._wbg_cb_unref();
        },
        __wbg_abort_cfab06d16d2d33a6: function() { return handleError(function (arg0) {
            arg0.abort();
        }, arguments); },
        __wbg_bound_88db1072ea68e901: function() { return handleError(function (arg0, arg1, arg2, arg3) {
            const ret = IDBKeyRange.bound(arg0, arg1, arg2 !== 0, arg3 !== 0);
            return ret;
        }, arguments); },
        __wbg_call_368fa9c372d473ba: function() { return handleError(function (arg0, arg1, arg2, arg3) {
            const ret = arg0.call(arg1, arg2, arg3);
            return ret;
        }, arguments); },
        __wbg_call_7f2987183bb62793: function() { return handleError(function (arg0, arg1) {
            const ret = arg0.call(arg1);
            return ret;
        }, arguments); },
        __wbg_call_d578befcc3145dee: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = arg0.call(arg1, arg2);
            return ret;
        }, arguments); },
        __wbg_charCodeAt_c4d7dfcfcb95ca62: function(arg0, arg1) {
            const ret = arg0.charCodeAt(arg1 >>> 0);
            return ret;
        },
        __wbg_commit_e9c1332714c53826: function() { return handleError(function (arg0) {
            arg0.commit();
        }, arguments); },
        __wbg_concat_75d6fa5e260203fb: function(arg0, arg1) {
            const ret = arg0.concat(arg1);
            return ret;
        },
        __wbg_construct_adeb3d5948c3d19a: function() { return handleError(function (arg0, arg1) {
            const ret = Reflect.construct(arg0, arg1);
            return ret;
        }, arguments); },
        __wbg_createObjectStore_6e567b25160be2fa: function() { return handleError(function (arg0, arg1, arg2, arg3) {
            const ret = arg0.createObjectStore(getStringFromWasm0(arg1, arg2), arg3);
            return ret;
        }, arguments); },
        __wbg_delete_fc24bd7dfa57938e: function() { return handleError(function (arg0, arg1) {
            const ret = arg0.delete(arg1);
            return ret;
        }, arguments); },
        __wbg_done_547d467e97529006: function(arg0) {
            const ret = arg0.done;
            return ret;
        },
        __wbg_entries_616b1a459b85be0b: function(arg0) {
            const ret = Object.entries(arg0);
            return ret;
        },
        __wbg_error_58469b8474e13592: function() { return handleError(function (arg0) {
            const ret = arg0.error;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        }, arguments); },
        __wbg_error_a6fa202b58aa1cd3: function(arg0, arg1) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg0;
                deferred0_1 = arg1;
                console.error(getStringFromWasm0(arg0, arg1));
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        },
        __wbg_from_741da0f916ab74aa: function(arg0) {
            const ret = Array.from(arg0);
            return ret;
        },
        __wbg_getAll_93336699ea033b51: function() { return handleError(function (arg0, arg1) {
            const ret = arg0.getAll(arg1);
            return ret;
        }, arguments); },
        __wbg_getDate_bafac038eaae076e: function(arg0) {
            const ret = arg0.getDate();
            return ret;
        },
        __wbg_getDay_6eebc8fe9cb183f5: function(arg0) {
            const ret = arg0.getDay();
            return ret;
        },
        __wbg_getFullYear_8f83597f7403c865: function(arg0) {
            const ret = arg0.getFullYear();
            return ret;
        },
        __wbg_getHours_81348c8e800060e7: function(arg0) {
            const ret = arg0.getHours();
            return ret;
        },
        __wbg_getMinutes_bd1ccf17dab913bf: function(arg0) {
            const ret = arg0.getMinutes();
            return ret;
        },
        __wbg_getMonth_288607689622719c: function(arg0) {
            const ret = arg0.getMonth();
            return ret;
        },
        __wbg_getRandomValues_15134f5c0ae6b0d0: function() { return handleError(function (arg0, arg1) {
            globalThis.crypto.getRandomValues(getArrayU8FromWasm0(arg0, arg1));
        }, arguments); },
        __wbg_getRandomValues_d49329ff89a07af1: function() { return handleError(function (arg0, arg1) {
            globalThis.crypto.getRandomValues(getArrayU8FromWasm0(arg0, arg1));
        }, arguments); },
        __wbg_getSeconds_edef7266627a185f: function(arg0) {
            const ret = arg0.getSeconds();
            return ret;
        },
        __wbg_getTime_f6ac312467f7cf09: function(arg0) {
            const ret = arg0.getTime();
            return ret;
        },
        __wbg_getTimezoneOffset_ac5be603b21a5797: function(arg0) {
            const ret = arg0.getTimezoneOffset();
            return ret;
        },
        __wbg_get_4848e350b40afc16: function(arg0, arg1) {
            const ret = arg0[arg1 >>> 0];
            return ret;
        },
        __wbg_get_ed0642c4b9d31ddf: function() { return handleError(function (arg0, arg1) {
            const ret = Reflect.get(arg0, arg1);
            return ret;
        }, arguments); },
        __wbg_get_f96702c6245e4ef9: function() { return handleError(function (arg0, arg1) {
            const ret = Reflect.get(arg0, arg1);
            return ret;
        }, arguments); },
        __wbg_get_unchecked_7d7babe32e9e6a54: function(arg0, arg1) {
            const ret = arg0[arg1 >>> 0];
            return ret;
        },
        __wbg_get_with_ref_key_6412cf3094599694: function(arg0, arg1) {
            const ret = arg0[arg1];
            return ret;
        },
        __wbg_global_e30ac0b7684506d0: function(arg0) {
            const ret = arg0.global;
            return ret;
        },
        __wbg_has_3ec5c22db2e5237a: function() { return handleError(function (arg0, arg1) {
            const ret = Reflect.has(arg0, arg1);
            return ret;
        }, arguments); },
        __wbg_indexedDB_065ce3ad400579e3: function() { return handleError(function (arg0) {
            const ret = arg0.indexedDB;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        }, arguments); },
        __wbg_indexedDB_a2139150e2ea2a08: function() { return handleError(function (arg0) {
            const ret = arg0.indexedDB;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        }, arguments); },
        __wbg_indexedDB_af74cb6df65fa636: function() { return handleError(function (arg0) {
            const ret = arg0.indexedDB;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        }, arguments); },
        __wbg_instanceof_ArrayBuffer_ff7c1337a5e3b33a: function(arg0) {
            let result;
            try {
                result = arg0 instanceof ArrayBuffer;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_DomException_37f96d3fb69189bd: function(arg0) {
            let result;
            try {
                result = arg0 instanceof DOMException;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_Error_e3390d6805733dad: function(arg0) {
            let result;
            try {
                result = arg0 instanceof Error;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_IdbDatabase_0af111edb4be95f4: function(arg0) {
            let result;
            try {
                result = arg0 instanceof IDBDatabase;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_IdbRequest_fc5918c726448f04: function(arg0) {
            let result;
            try {
                result = arg0 instanceof IDBRequest;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_Map_a10a2795ef4bfe97: function(arg0) {
            let result;
            try {
                result = arg0 instanceof Map;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_Uint8Array_4b8da683deb25d72: function(arg0) {
            let result;
            try {
                result = arg0 instanceof Uint8Array;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_isArray_db61795ad004c139: function(arg0) {
            const ret = Array.isArray(arg0);
            return ret;
        },
        __wbg_isSafeInteger_ea83862ba994770c: function(arg0) {
            const ret = Number.isSafeInteger(arg0);
            return ret;
        },
        __wbg_is_3ce118e1fc3aa47e: function(arg0, arg1) {
            const ret = Object.is(arg0, arg1);
            return ret;
        },
        __wbg_iterator_de403ef31815a3e6: function() {
            const ret = Symbol.iterator;
            return ret;
        },
        __wbg_length_0c32cb8543c8e4c8: function(arg0) {
            const ret = arg0.length;
            return ret;
        },
        __wbg_length_269224948362b9bf: function(arg0) {
            const ret = arg0.length;
            return ret;
        },
        __wbg_length_6e821edde497a532: function(arg0) {
            const ret = arg0.length;
            return ret;
        },
        __wbg_log_6a8b55ee2e172f54: function(arg0, arg1, arg2, arg3, arg4, arg5, arg6, arg7) {
            let deferred0_0;
            let deferred0_1;
            try {
                deferred0_0 = arg0;
                deferred0_1 = arg1;
                console.log(getStringFromWasm0(arg0, arg1), getStringFromWasm0(arg2, arg3), getStringFromWasm0(arg4, arg5), getStringFromWasm0(arg6, arg7));
            } finally {
                wasm.__wbindgen_free(deferred0_0, deferred0_1, 1);
            }
        },
        __wbg_lowerBound_279c232a69ac0f79: function() { return handleError(function (arg0, arg1) {
            const ret = IDBKeyRange.lowerBound(arg0, arg1 !== 0);
            return ret;
        }, arguments); },
        __wbg_message_52a9425f28c45ebc: function(arg0, arg1) {
            const ret = arg1.message;
            const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg_message_7367f8c7d0fa1589: function(arg0) {
            const ret = arg0.message;
            return ret;
        },
        __wbg_name_d7bb38b41d6d953e: function(arg0, arg1) {
            const ret = arg1.name;
            const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg_new_0_bfa2ef4bc447daa2: function() {
            const ret = new Date();
            return ret;
        },
        __wbg_new_0f6d2ddfe083319b: function(arg0) {
            const ret = new Date(arg0);
            return ret;
        },
        __wbg_new_227d7c05414eb861: function() {
            const ret = new Error();
            return ret;
        },
        __wbg_new_40792555590ec35c: function(arg0, arg1) {
            try {
                var state0 = {a: arg0, b: arg1};
                var cb0 = (arg0, arg1) => {
                    const a = state0.a;
                    state0.a = 0;
                    try {
                        return wasm_bindgen__convert__closures_____invoke__h0c5680e9ed94b2e6(a, state0.b, arg0, arg1);
                    } finally {
                        state0.a = a;
                    }
                };
                const ret = new Promise(cb0);
                return ret;
            } finally {
                state0.a = 0;
            }
        },
        __wbg_new_4f9fafbb3909af72: function() {
            const ret = new Object();
            return ret;
        },
        __wbg_new_99cabae501c0a8a0: function() {
            const ret = new Map();
            return ret;
        },
        __wbg_new_a560378ea1240b14: function(arg0) {
            const ret = new Uint8Array(arg0);
            return ret;
        },
        __wbg_new_e3b04b4d53d1b593: function(arg0, arg1) {
            const ret = new Error(getStringFromWasm0(arg0, arg1));
            return ret;
        },
        __wbg_new_f3c9df4f38f3f798: function() {
            const ret = new Array();
            return ret;
        },
        __wbg_new_from_slice_2580ff33d0d10520: function(arg0, arg1) {
            const ret = new Uint8Array(getArrayU8FromWasm0(arg0, arg1));
            return ret;
        },
        __wbg_new_typed_14d7cc391ce53d2c: function(arg0, arg1) {
            try {
                var state0 = {a: arg0, b: arg1};
                var cb0 = (arg0, arg1) => {
                    const a = state0.a;
                    state0.a = 0;
                    try {
                        return wasm_bindgen__convert__closures_____invoke__h0c5680e9ed94b2e6(a, state0.b, arg0, arg1);
                    } finally {
                        state0.a = a;
                    }
                };
                const ret = new Promise(cb0);
                return ret;
            } finally {
                state0.a = 0;
            }
        },
        __wbg_new_with_length_9cedd08484b73942: function(arg0) {
            const ret = new Uint8Array(arg0 >>> 0);
            return ret;
        },
        __wbg_new_with_year_month_day_d7dc1e63a7b42902: function(arg0, arg1, arg2) {
            const ret = new Date(arg0 >>> 0, arg1, arg2);
            return ret;
        },
        __wbg_next_01132ed6134b8ef5: function(arg0) {
            const ret = arg0.next;
            return ret;
        },
        __wbg_next_b3713ec761a9dbfd: function() { return handleError(function (arg0) {
            const ret = arg0.next();
            return ret;
        }, arguments); },
        __wbg_now_6798946be0e6fe2b: function() { return handleError(function () {
            const ret = Date.now();
            return ret;
        }, arguments); },
        __wbg_now_88621c9c9a4f3ffc: function() {
            const ret = Date.now();
            return ret;
        },
        __wbg_now_e7c6795a7f81e10f: function(arg0) {
            const ret = arg0.now();
            return ret;
        },
        __wbg_objectStore_3d4cade4416cd432: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = arg0.objectStore(getStringFromWasm0(arg1, arg2));
            return ret;
        }, arguments); },
        __wbg_open_ac04ec9d75d0eeaf: function() { return handleError(function (arg0, arg1, arg2, arg3) {
            const ret = arg0.open(getStringFromWasm0(arg1, arg2), arg3 >>> 0);
            return ret;
        }, arguments); },
        __wbg_pendingnativeread_new: function(arg0) {
            const ret = PendingNativeRead.__wrap(arg0);
            return ret;
        },
        __wbg_performance_3fcf6e32a7e1ed0a: function(arg0) {
            const ret = arg0.performance;
            return ret;
        },
        __wbg_prototypesetcall_3e05eb9545565046: function(arg0, arg1, arg2) {
            Uint8Array.prototype.set.call(getArrayU8FromWasm0(arg0, arg1), arg2);
        },
        __wbg_push_6bdbc990be5ac37b: function(arg0, arg1) {
            const ret = arg0.push(arg1);
            return ret;
        },
        __wbg_put_015a7e88e46a2502: function() { return handleError(function (arg0, arg1) {
            const ret = arg0.put(arg1);
            return ret;
        }, arguments); },
        __wbg_queueMicrotask_abaf92f0bd4e80a4: function(arg0) {
            const ret = arg0.queueMicrotask;
            return ret;
        },
        __wbg_queueMicrotask_df5a6dac26d818f3: function(arg0) {
            queueMicrotask(arg0);
        },
        __wbg_random_a72d453e63c9558c: function() {
            const ret = Math.random();
            return ret;
        },
        __wbg_readyState_accbdf425c074d9c: function(arg0) {
            const ret = arg0.readyState;
            return (__wbindgen_enum_IdbRequestReadyState.indexOf(ret) + 1 || 3) - 1;
        },
        __wbg_reject_1340e1211c01825b: function(arg0) {
            const ret = Promise.reject(arg0);
            return ret;
        },
        __wbg_resolve_0a79de24e9d2267b: function(arg0) {
            const ret = Promise.resolve(arg0);
            return ret;
        },
        __wbg_result_452c1006fc727317: function() { return handleError(function (arg0) {
            const ret = arg0.result;
            return ret;
        }, arguments); },
        __wbg_set_08463b1df38a7e29: function(arg0, arg1, arg2) {
            const ret = arg0.set(arg1, arg2);
            return ret;
        },
        __wbg_set_16a9c1a07b3d38ec: function(arg0, arg1, arg2) {
            arg0.set(getArrayU8FromWasm0(arg1, arg2));
        },
        __wbg_set_6be42768c690e380: function(arg0, arg1, arg2) {
            arg0[arg1] = arg2;
        },
        __wbg_set_6c60b2e8ad0e9383: function(arg0, arg1, arg2) {
            arg0[arg1 >>> 0] = arg2;
        },
        __wbg_set_8ee2d34facb8466e: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = Reflect.set(arg0, arg1, arg2);
            return ret;
        }, arguments); },
        __wbg_set_key_path_6edd6ee0e8d75af3: function(arg0, arg1) {
            arg0.keyPath = arg1;
        },
        __wbg_set_onabort_6b6df7a41aa97c23: function(arg0, arg1) {
            arg0.onabort = arg1;
        },
        __wbg_set_oncomplete_20fb27150b4ee0d4: function(arg0, arg1) {
            arg0.oncomplete = arg1;
        },
        __wbg_set_onerror_2b7dfa4e6dea4159: function(arg0, arg1) {
            arg0.onerror = arg1;
        },
        __wbg_set_onerror_3c4b5087146b11b6: function(arg0, arg1) {
            arg0.onerror = arg1;
        },
        __wbg_set_onsuccess_f7e5b5cbed5008b1: function(arg0, arg1) {
            arg0.onsuccess = arg1;
        },
        __wbg_set_onupgradeneeded_d7e8e03a1999bf5d: function(arg0, arg1) {
            arg0.onupgradeneeded = arg1;
        },
        __wbg_slice_afacba53cc65ec8e: function(arg0, arg1, arg2) {
            const ret = arg0.slice(arg1 >>> 0, arg2 >>> 0);
            return ret;
        },
        __wbg_stack_3b0d974bbf31e44f: function(arg0, arg1) {
            const ret = arg1.stack;
            const ptr1 = passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            const len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32(arg0 + 4 * 1, len1, true);
            getDataViewMemory0().setInt32(arg0 + 4 * 0, ptr1, true);
        },
        __wbg_static_accessor_GLOBAL_THIS_a1248013d790bf5f: function() {
            const ret = typeof globalThis === 'undefined' ? null : globalThis;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_static_accessor_GLOBAL_f2e0f995a21329ff: function() {
            const ret = typeof global === 'undefined' ? null : global;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_static_accessor_SELF_24f78b6d23f286ea: function() {
            const ret = typeof self === 'undefined' ? null : self;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_static_accessor_WINDOW_59fd959c540fe405: function() {
            const ret = typeof window === 'undefined' ? null : window;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_subarray_0f98d3fb634508ad: function(arg0, arg1, arg2) {
            const ret = arg0.subarray(arg1 >>> 0, arg2 >>> 0);
            return ret;
        },
        __wbg_target_732d56b173b7e87c: function(arg0) {
            const ret = arg0.target;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_then_00eed3ac0b8e82cb: function(arg0, arg1, arg2) {
            const ret = arg0.then(arg1, arg2);
            return ret;
        },
        __wbg_then_a0c8db0381c8994c: function(arg0, arg1) {
            const ret = arg0.then(arg1);
            return ret;
        },
        __wbg_toString_891d991e862e1d44: function(arg0) {
            const ret = arg0.toString();
            return ret;
        },
        __wbg_transaction_cc65dcef07fabb06: function(arg0) {
            const ret = arg0.transaction;
            return ret;
        },
        __wbg_transaction_f909284bfed41115: function() { return handleError(function (arg0, arg1, arg2, arg3) {
            const ret = arg0.transaction(getStringFromWasm0(arg1, arg2), __wbindgen_enum_IdbTransactionMode[arg3]);
            return ret;
        }, arguments); },
        __wbg_upperBound_2f3c07fb628c7a3c: function() { return handleError(function (arg0, arg1) {
            const ret = IDBKeyRange.upperBound(arg0, arg1 !== 0);
            return ret;
        }, arguments); },
        __wbg_value_7f6052747ccf940f: function(arg0) {
            const ret = arg0.value;
            return ret;
        },
        __wbg_wasmdb_new: function(arg0) {
            const ret = WasmDb.__wrap(arg0);
            return ret;
        },
        __wbg_wasmtransport_new: function(arg0) {
            const ret = WasmTransport.__wrap(arg0);
            return ret;
        },
        __wbg_wasmwrite_new: function(arg0) {
            const ret = WasmWrite.__wrap(arg0);
            return ret;
        },
        __wbindgen_cast_0000000000000001: function(arg0, arg1) {
            // Cast intrinsic for `Closure(Closure { owned: true, function: Function { arguments: [Externref], shim_idx: 2309, ret: Result(Unit), inner_ret: Some(Result(Unit)) }, mutable: true }) -> Externref`.
            const ret = makeMutClosure(arg0, arg1, wasm_bindgen__convert__closures_____invoke__hf2d3ca0c7acb67d9);
            return ret;
        },
        __wbindgen_cast_0000000000000002: function(arg0, arg1) {
            // Cast intrinsic for `Closure(Closure { owned: true, function: Function { arguments: [Externref], shim_idx: 6, ret: NamedExternref("Promise<any>"), inner_ret: Some(NamedExternref("Promise<any>")) }, mutable: true }) -> Externref`.
            const ret = makeMutClosure(arg0, arg1, wasm_bindgen__convert__closures_____invoke__h62288b7949ffd3ae);
            return ret;
        },
        __wbindgen_cast_0000000000000003: function(arg0, arg1) {
            // Cast intrinsic for `Closure(Closure { owned: true, function: Function { arguments: [NamedExternref("Event")], shim_idx: 366, ret: Unit, inner_ret: Some(Unit) }, mutable: true }) -> Externref`.
            const ret = makeMutClosure(arg0, arg1, wasm_bindgen__convert__closures_____invoke__hf83e1094fac4ab4c);
            return ret;
        },
        __wbindgen_cast_0000000000000004: function(arg0, arg1) {
            // Cast intrinsic for `Closure(Closure { owned: true, function: Function { arguments: [NamedExternref("IDBVersionChangeEvent")], shim_idx: 7, ret: Result(Unit), inner_ret: Some(Result(Unit)) }, mutable: true }) -> Externref`.
            const ret = makeMutClosure(arg0, arg1, wasm_bindgen__convert__closures_____invoke__h05f77cffdc1766b5);
            return ret;
        },
        __wbindgen_cast_0000000000000005: function(arg0, arg1) {
            // Cast intrinsic for `Closure(Closure { owned: true, function: Function { arguments: [], shim_idx: 273, ret: Unit, inner_ret: Some(Unit) }, mutable: true }) -> Externref`.
            const ret = makeMutClosure(arg0, arg1, wasm_bindgen__convert__closures_____invoke__h69610db431037c77);
            return ret;
        },
        __wbindgen_cast_0000000000000006: function(arg0, arg1) {
            // Cast intrinsic for `Closure(Closure { owned: true, function: Function { arguments: [], shim_idx: 368, ret: Unit, inner_ret: Some(Unit) }, mutable: true }) -> Externref`.
            const ret = makeMutClosure(arg0, arg1, wasm_bindgen__convert__closures_____invoke__h492b14c1fd17d971);
            return ret;
        },
        __wbindgen_cast_0000000000000007: function(arg0) {
            // Cast intrinsic for `F64 -> Externref`.
            const ret = arg0;
            return ret;
        },
        __wbindgen_cast_0000000000000008: function(arg0) {
            // Cast intrinsic for `I64 -> Externref`.
            const ret = arg0;
            return ret;
        },
        __wbindgen_cast_0000000000000009: function(arg0, arg1) {
            // Cast intrinsic for `Ref(String) -> Externref`.
            const ret = getStringFromWasm0(arg0, arg1);
            return ret;
        },
        __wbindgen_cast_000000000000000a: function(arg0) {
            // Cast intrinsic for `U64 -> Externref`.
            const ret = BigInt.asUintN(64, arg0);
            return ret;
        },
        __wbindgen_init_externref_table: function() {
            const table = wasm.__wbindgen_externrefs;
            const offset = table.grow(4);
            table.set(0, undefined);
            table.set(offset + 0, undefined);
            table.set(offset + 1, null);
            table.set(offset + 2, true);
            table.set(offset + 3, false);
        },
    };
    return {
        __proto__: null,
        "./jazz_wasm_bg.js": import0,
    };
}

function wasm_bindgen__convert__closures_____invoke__h69610db431037c77(arg0, arg1) {
    wasm.wasm_bindgen__convert__closures_____invoke__h69610db431037c77(arg0, arg1);
}

function wasm_bindgen__convert__closures_____invoke__h492b14c1fd17d971(arg0, arg1) {
    wasm.wasm_bindgen__convert__closures_____invoke__h492b14c1fd17d971(arg0, arg1);
}

function wasm_bindgen__convert__closures_____invoke__hf83e1094fac4ab4c(arg0, arg1, arg2) {
    wasm.wasm_bindgen__convert__closures_____invoke__hf83e1094fac4ab4c(arg0, arg1, arg2);
}

function wasm_bindgen__convert__closures_____invoke__h62288b7949ffd3ae(arg0, arg1, arg2) {
    const ret = wasm.wasm_bindgen__convert__closures_____invoke__h62288b7949ffd3ae(arg0, arg1, arg2);
    return ret;
}

function wasm_bindgen__convert__closures_____invoke__hf2d3ca0c7acb67d9(arg0, arg1, arg2) {
    const ret = wasm.wasm_bindgen__convert__closures_____invoke__hf2d3ca0c7acb67d9(arg0, arg1, arg2);
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}

function wasm_bindgen__convert__closures_____invoke__h05f77cffdc1766b5(arg0, arg1, arg2) {
    const ret = wasm.wasm_bindgen__convert__closures_____invoke__h05f77cffdc1766b5(arg0, arg1, arg2);
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}

function wasm_bindgen__convert__closures_____invoke__h0c5680e9ed94b2e6(arg0, arg1, arg2, arg3) {
    wasm.wasm_bindgen__convert__closures_____invoke__h0c5680e9ed94b2e6(arg0, arg1, arg2, arg3);
}


const __wbindgen_enum_IdbRequestReadyState = ["pending", "done"];


const __wbindgen_enum_IdbTransactionMode = ["readonly", "readwrite", "versionchange", "readwriteflush", "cleanup"];
const WasmDbFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_wasmdb_free(ptr >>> 0, 1));
const PendingNativeReadFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_pendingnativeread_free(ptr >>> 0, 1));
const WasmPendingSubscriptionFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_wasmpendingsubscription_free(ptr >>> 0, 1));
const WasmPermissionAdviceRequestFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_wasmpermissionadvicerequest_free(ptr >>> 0, 1));
const StreamingMutationFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_streamingmutation_free(ptr >>> 0, 1));
const WasmTransportFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_wasmtransport_free(ptr >>> 0, 1));
const UpstreamLinkFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_upstreamlink_free(ptr >>> 0, 1));
const WasmWriteFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_wasmwrite_free(ptr >>> 0, 1));

function addToExternrefTable0(obj) {
    const idx = wasm.__externref_table_alloc();
    wasm.__wbindgen_externrefs.set(idx, obj);
    return idx;
}

const CLOSURE_DTORS = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(state => wasm.__wbindgen_destroy_closure(state.a, state.b));

function debugString(val) {
    // primitive types
    const type = typeof val;
    if (type == 'number' || type == 'boolean' || val == null) {
        return  `${val}`;
    }
    if (type == 'string') {
        return `"${val}"`;
    }
    if (type == 'symbol') {
        const description = val.description;
        if (description == null) {
            return 'Symbol';
        } else {
            return `Symbol(${description})`;
        }
    }
    if (type == 'function') {
        const name = val.name;
        if (typeof name == 'string' && name.length > 0) {
            return `Function(${name})`;
        } else {
            return 'Function';
        }
    }
    // objects
    if (Array.isArray(val)) {
        const length = val.length;
        let debug = '[';
        if (length > 0) {
            debug += debugString(val[0]);
        }
        for(let i = 1; i < length; i++) {
            debug += ', ' + debugString(val[i]);
        }
        debug += ']';
        return debug;
    }
    // Test for built-in
    const builtInMatches = /\[object ([^\]]+)\]/.exec(toString.call(val));
    let className;
    if (builtInMatches && builtInMatches.length > 1) {
        className = builtInMatches[1];
    } else {
        // Failed to match the standard '[object ClassName]'
        return toString.call(val);
    }
    if (className == 'Object') {
        // we're a user defined class or Object
        // JSON.stringify avoids problems with cycles, and is generally much
        // easier than looping through ownProperties of `val`.
        try {
            return 'Object(' + JSON.stringify(val) + ')';
        } catch (_) {
            return 'Object';
        }
    }
    // errors
    if (val instanceof Error) {
        return `${val.name}: ${val.message}\n${val.stack}`;
    }
    // TODO we could test for more things here, like `Set`s and `Map`s.
    return className;
}

function getArrayJsValueFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    const mem = getDataViewMemory0();
    const result = [];
    for (let i = ptr; i < ptr + 4 * len; i += 4) {
        result.push(wasm.__wbindgen_externrefs.get(mem.getUint32(i, true)));
    }
    wasm.__externref_drop_slice(ptr, len);
    return result;
}

function getArrayU8FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint8ArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
}

let cachedDataViewMemory0 = null;
function getDataViewMemory0() {
    if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || (cachedDataViewMemory0.buffer.detached === undefined && cachedDataViewMemory0.buffer !== wasm.memory.buffer)) {
        cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
    }
    return cachedDataViewMemory0;
}

function getStringFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return decodeText(ptr, len);
}

let cachedUint8ArrayMemory0 = null;
function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

function handleError(f, args) {
    try {
        return f.apply(this, args);
    } catch (e) {
        const idx = addToExternrefTable0(e);
        wasm.__wbindgen_exn_store(idx);
    }
}

function isLikeNone(x) {
    return x === undefined || x === null;
}

function makeMutClosure(arg0, arg1, f) {
    const state = { a: arg0, b: arg1, cnt: 1 };
    const real = (...args) => {

        // First up with a closure we increment the internal reference
        // count. This ensures that the Rust closure environment won't
        // be deallocated while we're invoking it.
        state.cnt++;
        const a = state.a;
        state.a = 0;
        try {
            return f(a, state.b, ...args);
        } finally {
            state.a = a;
            real._wbg_cb_unref();
        }
    };
    real._wbg_cb_unref = () => {
        if (--state.cnt === 0) {
            wasm.__wbindgen_destroy_closure(state.a, state.b);
            state.a = 0;
            CLOSURE_DTORS.unregister(state);
        }
    };
    CLOSURE_DTORS.register(real, state, state);
    return real;
}

function passArray8ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 1, 1) >>> 0;
    getUint8ArrayMemory0().set(arg, ptr / 1);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

function passStringToWasm0(arg, malloc, realloc) {
    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length, 1) >>> 0;
        getUint8ArrayMemory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;

    const mem = getUint8ArrayMemory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }
    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
        const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
        const ret = cachedTextEncoder.encodeInto(arg, view);

        offset += ret.written;
        ptr = realloc(ptr, len, offset, 1) >>> 0;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

function takeFromExternrefTable0(idx) {
    const value = wasm.__wbindgen_externrefs.get(idx);
    wasm.__externref_table_dealloc(idx);
    return value;
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
cachedTextDecoder.decode();
const MAX_SAFARI_DECODE_BYTES = 2146435072;
let numBytesDecoded = 0;
function decodeText(ptr, len) {
    numBytesDecoded += len;
    if (numBytesDecoded >= MAX_SAFARI_DECODE_BYTES) {
        cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });
        cachedTextDecoder.decode();
        numBytesDecoded = len;
    }
    return cachedTextDecoder.decode(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

const cachedTextEncoder = new TextEncoder();

if (!('encodeInto' in cachedTextEncoder)) {
    cachedTextEncoder.encodeInto = function (arg, view) {
        const buf = cachedTextEncoder.encode(arg);
        view.set(buf);
        return {
            read: arg.length,
            written: buf.length
        };
    };
}

let WASM_VECTOR_LEN = 0;

let wasmModule, wasm;
function __wbg_finalize_init(instance, module) {
    wasm = instance.exports;
    wasmModule = module;
    cachedDataViewMemory0 = null;
    cachedUint8ArrayMemory0 = null;
    wasm.__wbindgen_start();
    return wasm;
}

async function __wbg_load(module, imports) {
    if (typeof Response === 'function' && module instanceof Response) {
        if (typeof WebAssembly.instantiateStreaming === 'function') {
            try {
                return await WebAssembly.instantiateStreaming(module, imports);
            } catch (e) {
                const validResponse = module.ok && expectedResponseType(module.type);

                if (validResponse && module.headers.get('Content-Type') !== 'application/wasm') {
                    console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);

                } else { throw e; }
            }
        }

        const bytes = await module.arrayBuffer();
        return await WebAssembly.instantiate(bytes, imports);
    } else {
        const instance = await WebAssembly.instantiate(module, imports);

        if (instance instanceof WebAssembly.Instance) {
            return { instance, module };
        } else {
            return instance;
        }
    }

    function expectedResponseType(type) {
        switch (type) {
            case 'basic': case 'cors': case 'default': return true;
        }
        return false;
    }
}

function initSync(module) {
    if (wasm !== undefined) return wasm;


    if (module !== undefined) {
        if (Object.getPrototypeOf(module) === Object.prototype) {
            ({module} = module)
        } else {
            console.warn('using deprecated parameters for `initSync()`; pass a single object instead')
        }
    }

    const imports = __wbg_get_imports();
    if (!(module instanceof WebAssembly.Module)) {
        module = new WebAssembly.Module(module);
    }
    const instance = new WebAssembly.Instance(module, imports);
    return __wbg_finalize_init(instance, module);
}

async function __wbg_init(module_or_path) {
    if (wasm !== undefined) return wasm;


    if (module_or_path !== undefined) {
        if (Object.getPrototypeOf(module_or_path) === Object.prototype) {
            ({module_or_path} = module_or_path)
        } else {
            console.warn('using deprecated parameters for the initialization function; pass a single object instead')
        }
    }

    if (module_or_path === undefined) {
        module_or_path = new URL('jazz_wasm_bg.wasm', import.meta.url);
    }
    const imports = __wbg_get_imports();

    if (typeof module_or_path === 'string' || (typeof Request === 'function' && module_or_path instanceof Request) || (typeof URL === 'function' && module_or_path instanceof URL)) {
        module_or_path = fetch(module_or_path);
    }

    const { instance, module } = await __wbg_load(await module_or_path, imports);

    return __wbg_finalize_init(instance, module);
}

export { initSync, __wbg_init as default };
