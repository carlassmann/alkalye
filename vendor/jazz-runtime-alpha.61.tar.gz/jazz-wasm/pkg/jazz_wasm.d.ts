/* tslint:disable */
/* eslint-disable */

export class PendingNativeRead {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    cancel(): void;
    poll(): any;
}

/**
 * A large value uploaded in chunks, then published as one row mutation.
 */
export class StreamingMutation {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    abort(): Promise<any>;
    finish(): Promise<any>;
    /**
     * Stage the value's row mutation in the transaction it began in.
     */
    finishInTransaction(): void;
    push(chunk: Uint8Array): Promise<any>;
}

/**
 * The shared upstream link machine (`jazz::link`), which decides when the
 * runtime's WebSocket connects, backs off and reports an outage. The runtime
 * owns the socket and the timer and steps the machine with JSON documents.
 */
export class UpstreamLink {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Apply one input observed at `now_ms`; returns the actions, events and
     * status as JSON.
     */
    handle(now_ms: number, input: string): string;
    /**
     * `seed` drives the retry jitter.
     */
    constructor(seed: number);
}

export class WasmDb {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Serve a subscriber (a tab's in-memory database) as `identity`.
     */
    acceptSubscriber(identity: Uint8Array, claims: any, _local_epoch?: bigint | null): Promise<any>;
    /**
     * Attach a browser-local follower for a verified first-party identity.
     *
     * This is deliberately separate from [`Self::accept_subscriber`]: raw
     * serialized identities must keep rejecting Jazz-reserved issuers, while
     * a local-first or anonymous browser worker can prove its own identity
     * with the same signed capability that opened the worker database.
     */
    acceptSubscriberWithSelfSignedProof(claims: any, token: string, app_id: string, claimed_author: string, _local_epoch?: bigint | null): Promise<any>;
    all(query: Uint8Array, opts: any, open_transaction_id: string | null | undefined, author: Uint8Array | null | undefined, claims: any): any;
    beginStreamingMutation(table: string, row_id: Uint8Array, cells: Uint8Array, column: string, mutation?: string | null, author?: Uint8Array | null, attribution?: Uint8Array | null, updated_at_ms?: number | null, head?: any | null, base?: any | null, transaction?: string | null): StreamingMutation;
    /**
     * Begin one owner-wide transaction.
     */
    beginTransaction(open_transaction_id: string, kind: string, author?: Uint8Array | null, attribution?: Uint8Array | null): void;
    /**
     * A replica's own policy evidence may be incomplete, so it never
     * decides locally; ask the authority with `requestInsertPermissionAdvice`.
     */
    canInsert(_table: string, _cells: Uint8Array): string;
    captureSnapshot(): any;
    close(): Promise<any>;
    /**
     * Commit an owner-wide transaction by id.
     */
    commitTransaction(open_transaction_id: string, kind?: string | null): WasmWrite;
    /**
     * Connect to the server over byte frames the host carries: each frame
     * is one postcard `SyncMessage`.
     */
    connectUpstream(): Promise<any>;
    /**
     * Connect after the carrier accepted the server Hello. Negotiated
     * features must be compiled in; the rest of the session context
     * (authority endpoints, epochs) has no counterpart on SQLite's sync, so
     * this is otherwise [`Self::connect_upstream`].
     */
    connectUpstreamWithSession(_protocol_version: number, features: number, remote_node: Uint8Array, _remote_epoch: bigint, local_node: Uint8Array, _local_epoch: bigint): Promise<any>;
    /**
     * A fresh upstream link machine for this runtime's server connection;
     * `seed` drives its retry jitter.
     */
    createUpstreamLink(seed: number): UpstreamLink;
    delete(table: string, row_id: Uint8Array, options: any): WasmWrite;
    deleteInTransaction(open_transaction_id: string, table: string, row_id: Uint8Array, options: any): void;
    /**
     * Delete a durable browser store (`{ backend, path }`, as for
     * `openBrowser`). No database may have it open.
     */
    static destroyBrowserStorage(storage: any, database: string): Promise<void>;
    /**
     * Run one idempotent expiry pass; browser hosts normally call this from a timer.
     */
    evictExpiredStagedLargeValues(): Promise<any>;
    /**
     * Wait until every commit so far is in the browser store's backing
     * storage. A no-op for in-memory databases.
     */
    flush(): Promise<any>;
    /**
     * The newest transaction time this database handed out under its
     * node (a `TxTime` is the commit seq). A leased node's next holder
     * seeds it through `seedForegroundTxTimeHighWater`.
     */
    foregroundTxTimeHighWater(): Promise<any>;
    insert(table: string, cells: Uint8Array, options: any): WasmWrite;
    insertInTransaction(open_transaction_id: string, table: string, cells: Uint8Array, options: any): Uint8Array;
    /**
     * Exact local state for the write-merge bridge: the row as stored,
     * deleted or not. Write authorization remains at the mutation boundary;
     * this is not a query.
     */
    localCurrentRow(table: string, row_id: Uint8Array): Uint8Array;
    /**
     * Register a callback for rejected writes that no active wait consumed.
     */
    onMutationError(callback: Function): void;
    /**
     * Register `callback(message)`, called when writing the browser store
     * to its backing storage starts failing (storage full, most often)
     * and `callback(null)` once a write succeeds again. Meanwhile commits
     * stay in memory, tabs do not hear their writes are `Local`, and
     * `flush` fails with code `storage`. Called at once if failing now.
     */
    onStorageFailure(callback: Function): void;
    /**
     * Open the durable store a browser worker owns. `storage` selects the
     * file: `{ backend?: "indexeddb", path?: string }` (see [`browser`]).
     * The default file is named after `database`, the physical database
     * name the worker admitted.
     */
    static openBrowser(storage: any, schema: Uint8Array, config: Uint8Array, database: string): Promise<WasmDb>;
    static openBrowserWithSelfSignedProof(storage: any, schema: Uint8Array, config: Uint8Array, token: string, app_id: string, claimed_author: string, database: string): Promise<WasmDb>;
    static openMemory(schema: Uint8Array, config: Uint8Array): WasmDb;
    /**
     * Open a deliberate backend runtime. This remains a separate ABI from
     * `openMemory`: the public raw-open configuration can never select the
     * privileged system author.
     */
    static openMemoryAsBackend(schema: Uint8Array, config: Uint8Array): WasmDb;
    /**
     * Open with a verified Jazz self-signed client identity. This deliberately
     * stays separate from `openMemory`: untrusted open config bytes can never
     * select a Jazz-reserved identity.
     */
    static openMemoryWithSelfSignedProof(schema: Uint8Array, config: Uint8Array, token: string, app_id: string, claimed_author: string): WasmDb;
    /**
     * Register a typed schema view backed by this same runtime owner, of
     * an app shipping `migrations` (its bundle as JSON).
     */
    registerSchema(schema: Uint8Array, migrations?: Uint8Array | null): WasmDb;
    requestDeletePermissionAdvice(table: string, row_id: Uint8Array): WasmPermissionAdviceRequest;
    requestInsertPermissionAdvice(table: string, cells: Uint8Array): WasmPermissionAdviceRequest;
    requestReadPermissionAdvice(table: string, row_id: Uint8Array): WasmPermissionAdviceRequest;
    requestUpdatePermissionAdvice(table: string, row_id: Uint8Array, patch: Uint8Array): WasmPermissionAdviceRequest;
    restore(table: string, row_id: Uint8Array, cells: Uint8Array | null | undefined, options: any): WasmWrite;
    restoreInTransaction(open_transaction_id: string, table: string, row_id: Uint8Array, cells: Uint8Array | null | undefined, options: any): void;
    /**
     * Roll back an owner-wide open transaction by id.
     */
    rollbackTransaction(open_transaction_id: string): void;
    /**
     * Continue after a previous holder of this node: no transaction time
     * at or below `high_water` is reused.
     */
    seedForegroundTxTimeHighWater(high_water: bigint): void;
    setIdentityClaims(author: Uint8Array, claims: any): void;
    /**
     * Configure Jazz-owned upload ingress and unpublished-tree expiry limits.
     */
    setLargeValueStagingPolicy(incoming_bytes_per_window: number, window_ms: number, max_age_ms?: number | null): void;
    /**
     * The optimistic in-memory side of a browser client/worker pair: its
     * subscriptions open with the worker's answer.
     */
    setNonDurableClient(): void;
    /**
     * Report what the host knows about the path to the authoritative server
     * (`"none" | "attempting" | "live" | "failed"`; the TypeScript names
     * `"connecting" | "connected" | "unavailable"` are accepted as aliases).
     */
    setRemoteLinkHint(state: string): void;
    /**
     * Bind correlation claims to this already-open client's own identity.
     * This does not grant a different author or enable serving reads.
     */
    setSessionClaims(claims: any): any;
    /**
     * Report query runs of at least `ms` milliseconds (default 50); 0
     * turns the slow-query log off.
     */
    setSlowQueryThresholdMs(ms: number): void;
    /**
     * The host's tick callback: called with `"immediate"` whenever there
     * is sync work (a local write to upload, frames to apply).
     */
    setTickScheduler(callback: Function): void;
    subscribe(query: Uint8Array, opts: any, author: Uint8Array | null | undefined, claims: any): any;
    /**
     * The slow-query report due now: one line per slow query shape,
     * naming `app`: the first at once, then at most every 10 seconds. The caller
     * writes each line with `console.warn`.
     */
    takeSlowQueryReport(app?: string | null): string[];
    tick(): Promise<any>;
    update(table: string, row_id: Uint8Array, patch: Uint8Array, options: any): WasmWrite;
    updateInTransaction(open_transaction_id: string, table: string, row_id: Uint8Array, patch: Uint8Array, options: any): void;
    updateLargeValues(table: string, row_id: Uint8Array, patch: Uint8Array, mutations: any, updated_at_ms?: number | null): WasmWrite;
    /**
     * Typed partial-value updates staged inside an open transaction.
     */
    updateLargeValuesInTransaction(open_transaction_id: string, table: string, row_id: Uint8Array, patch: Uint8Array, mutations: any, updated_at_ms?: number | null): void;
    /**
     * This store's uploads: how many still wait for the server's verdict
     * and since when, and what the server refused since it opened
     * (`{ pending, oldestPendingAt, rejected, lastRejection }`).
     */
    uploadStatus(): any;
    upsert(table: string, row_id: Uint8Array, cells: Uint8Array, options: any): WasmWrite;
    upsertInTransaction(open_transaction_id: string, table: string, row_id: Uint8Array, cells: Uint8Array, options: any): void;
    /**
     * Resolve once every local write so far reached `tier`. Settling
     * `cancelled` stops a wait that is still pending and rejects it, so a
     * caller that gives up does not leave the core waiter parked.
     */
    waitForPendingWrites(tier: string, cancelled?: Promise<any> | null): Promise<any>;
    /**
     * Exact wire capabilities compiled into this WASM artifact.
     */
    wireFeatures(): number;
}

export class WasmPendingSubscription {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    cancel(): void;
    poll(): any | undefined;
    setWake(callback: Function): void;
}

/**
 * One permission preflight sent to the upstream authority.
 * One permission preflight sent to the upstream authority.
 */
export class WasmPermissionAdviceRequest {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Resolve the promise as `"unknown"`; a late answer is ignored.
     */
    cancel(): void;
    readonly promise: Promise<any>;
}

/**
 * One sync link, carried by the host as byte frames. Frames are applied
 * and produced by the database's tick.
 */
export class WasmTransport {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Never resolves: there is no auxiliary lane to produce output.
     */
    auxiliaryOutboundReady(): Promise<any>;
    auxiliaryReceiveTimeoutMs(): number | undefined;
    clearOutboundScheduler(): void;
    close(): boolean;
    expireAuxiliaryReceive(): void;
    recvAuxiliaryWireFrames(_max_frames?: number | null, _max_bytes?: number | null): Array<any>;
    recvWireFrames(): Array<any>;
    /**
     * SQLite's sync has no auxiliary chunk lane: large-value chunks travel
     * as ordinary sync messages. Every frame belongs to the ordinary lane.
     */
    routeAuxiliaryWireFrame(frame: Uint8Array): Promise<any>;
    sendWireFrame(frame: Uint8Array): void;
    sendWireFrames(frames: Array<any>): void;
    setAuxiliaryTraceEnabled(_enabled: boolean): void;
    setOutboundScheduler(callback: Function): void;
    takeAuxiliaryTrace(): Array<any>;
    /**
     * Tick the database this link belongs to: apply received frames, send
     * what is due. Resolves with the number of frames still to send.
     */
    tick(): Promise<any>;
    updateAuthenticatedClaims(claims: any): Promise<any>;
    /**
     * Why the database dropped this upstream link on its own, as an
     * `Error` with the core's stable `code` (`authority_changed` for a
     * server whose store was recreated), or `null` while the link stands.
     * The host stops the link with it rather than retry.
     */
    upstreamRefusal(): any;
}

export class WasmWrite {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    close(): boolean;
    /**
     * Resolve once the write reached `tier`: at once for `none` and
     * `local` (the commit is in the store when the write call returns), on
     * the server's acceptance for `global`, rejecting if it refused.
     */
    wait(tier: string, observe_only?: boolean | null): Promise<any>;
    writeState(): any;
    readonly payload: Uint8Array;
    readonly rowId: Uint8Array;
    readonly txId: string;
}

/**
 * Test-only bridge for executing the Rust-owned v1 binding corpus through the
 * generated WASM artifact. The JavaScript test still uses the production
 * decoder for every returned postcard payload.
 */
export function __testBindingCodecGoldenFixture(): string;

/**
 * Test-only: read one pinned wire corpus batch through the generated WASM
 * artifact, as `reader` (`"server-opening"`, `"server"` or `"client"`)
 * would, with the production frame and sync message decoders. Not a
 * browser transport API.
 */
export function __testValidateWireFrameBatchCorpus(batch: Uint8Array, reader: string, negotiated_features: string): void;

/**
 * Test-only feature inventory paired with [`test_validate_wire_frame_batch_corpus`].
 */
export function __testWireFrameCorpusFeatures(): string;

/**
 * The anchor at `position` (UTF-16 code units) of `text`.
 */
export function captureTextAnchor(text: string, version: number | null | undefined, position: number, side: any): any;

/**
 * The range `start..end` (UTF-16 code units) of `text`.
 */
export function captureTextRange(text: string, version: number | null | undefined, start: number, end: number): any;

/**
 * Get the current timestamp in milliseconds since Unix epoch.
 */
export function currentTimestamp(): bigint;

/**
 * Derive a stable local-first user id from a base64url-encoded 32-byte seed.
 */
export function deriveUserId(seed_b64: string): string;

/**
 * Drain buffered tracing entries as a JavaScript array.
 */
export function drainTraceEntries(): any;

/**
 * Generate a new UUID v7 (time-ordered).
 *
 * Useful when a caller wants the default generated row-id shape.
 */
export function generateId(): string;

/**
 * Initialize the WASM module.
 *
 * Sets up the panic hook for better error messages in the browser console.
 * Tracing is initialized by the first owning database open, after callers
 * have selected `globalThis.__JAZZ_WASM_LOG_LEVEL`.
 */
export function init(): void;

/**
 * Mint an anonymous identity JWT from a base64url-encoded 32-byte seed.
 */
export function mintAnonymousToken(seed_b64: string, audience: string, ttl_seconds: number, now_seconds: bigint): string;

/**
 * Mint a local-first identity JWT from a base64url-encoded 32-byte seed.
 */
export function mintLocalFirstToken(seed_b64: string, audience: string, ttl_seconds: number, now_seconds: bigint): string;

/**
 * Exact build/ABI fingerprint for this generated WASM artifact.
 */
export function nativeArtifactFingerprint(): string;

/**
 * Where `anchor` lands in `text`: `{ position, confidence, ambiguous }`.
 */
export function resolveTextAnchor(anchor: any, text: string, version?: number | null): any;

/**
 * Where `range` lands in `text`: `{ start, end, confidence, ambiguous }`.
 */
export function resolveTextRange(range: any, text: string, version?: number | null): any;

/**
 * Install the JSON Schema validator for JSON columns.
 *
 * The browser build leaves the Rust validator out to keep the binary small.
 * `compile` takes a declared schema as JSON text and returns a check that
 * takes a value as JSON text and returns why it does not match, or
 * `undefined`. `compile` throws when the schema itself is invalid; a check
 * that throws is reported as the validator failing, not as a mismatch.
 * Until this is called, JSON column schemas are reported as unavailable.
 */
export function setJsonSchemaValidator(compile: Function): void;

/**
 * Enable or disable buffering of tracing entries for JavaScript drains.
 */
export function setTraceEntryCollectionEnabled(enabled: boolean): void;

/**
 * Register a callback invoked when buffered tracing entries are ready.
 * Returns an unsubscribe function.
 */
export function subscribeTraceEntries(callback: Function): Function;

/**
 * Validate a schema and its embedded permissions without opening a database.
 */
export function validateSchema(schema: Uint8Array): void;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __testBindingCodecGoldenFixture: () => [number, number];
    readonly __testValidateWireFrameBatchCorpus: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number];
    readonly __testWireFrameCorpusFeatures: () => [number, number];
    readonly __wbg_pendingnativeread_free: (a: number, b: number) => void;
    readonly __wbg_streamingmutation_free: (a: number, b: number) => void;
    readonly __wbg_upstreamlink_free: (a: number, b: number) => void;
    readonly __wbg_wasmdb_free: (a: number, b: number) => void;
    readonly __wbg_wasmpendingsubscription_free: (a: number, b: number) => void;
    readonly __wbg_wasmpermissionadvicerequest_free: (a: number, b: number) => void;
    readonly __wbg_wasmtransport_free: (a: number, b: number) => void;
    readonly __wbg_wasmwrite_free: (a: number, b: number) => void;
    readonly currentTimestamp: () => bigint;
    readonly deriveUserId: (a: number, b: number) => [number, number, number, number];
    readonly generateId: () => [number, number];
    readonly mintAnonymousToken: (a: number, b: number, c: number, d: number, e: number, f: bigint) => [number, number, number, number];
    readonly mintLocalFirstToken: (a: number, b: number, c: number, d: number, e: number, f: bigint) => [number, number, number, number];
    readonly nativeArtifactFingerprint: () => [number, number];
    readonly pendingnativeread_cancel: (a: number) => void;
    readonly pendingnativeread_poll: (a: number) => [number, number, number];
    readonly setTraceEntryCollectionEnabled: (a: number) => void;
    readonly upstreamlink_handle: (a: number, b: number, c: number, d: number) => [number, number, number, number];
    readonly upstreamlink_new: (a: number) => number;
    readonly validateSchema: (a: number, b: number) => [number, number];
    readonly wasmdb_acceptSubscriber: (a: number, b: number, c: number, d: any, e: number, f: bigint) => [number, number, number];
    readonly wasmdb_acceptSubscriberWithSelfSignedProof: (a: number, b: any, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: bigint) => [number, number, number];
    readonly wasmdb_all: (a: number, b: number, c: number, d: any, e: number, f: number, g: number, h: number, i: any) => [number, number, number];
    readonly wasmdb_beginStreamingMutation: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number, l: number, m: number, n: number, o: number, p: number, q: number, r: number, s: number, t: number, u: number) => [number, number, number];
    readonly wasmdb_beginTransaction: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number) => [number, number];
    readonly wasmdb_canInsert: (a: number, b: number, c: number, d: number, e: number) => [number, number, number, number];
    readonly wasmdb_captureSnapshot: (a: number) => [number, number, number];
    readonly wasmdb_close: (a: number) => any;
    readonly wasmdb_commitTransaction: (a: number, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly wasmdb_connectUpstream: (a: number) => [number, number, number];
    readonly wasmdb_connectUpstreamWithSession: (a: number, b: number, c: number, d: number, e: number, f: bigint, g: number, h: number, i: bigint) => [number, number, number];
    readonly wasmdb_createUpstreamLink: (a: number, b: number) => number;
    readonly wasmdb_delete: (a: number, b: number, c: number, d: number, e: number, f: any) => [number, number, number];
    readonly wasmdb_deleteInTransaction: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: any) => [number, number];
    readonly wasmdb_destroyBrowserStorage: (a: any, b: number, c: number) => any;
    readonly wasmdb_evictExpiredStagedLargeValues: (a: number) => any;
    readonly wasmdb_flush: (a: number) => any;
    readonly wasmdb_foregroundTxTimeHighWater: (a: number) => [number, number, number];
    readonly wasmdb_insert: (a: number, b: number, c: number, d: number, e: number, f: any) => [number, number, number];
    readonly wasmdb_insertInTransaction: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: any) => [number, number, number, number];
    readonly wasmdb_localCurrentRow: (a: number, b: number, c: number, d: number, e: number) => [number, number, number, number];
    readonly wasmdb_onMutationError: (a: number, b: any) => void;
    readonly wasmdb_onStorageFailure: (a: number, b: any) => void;
    readonly wasmdb_openBrowser: (a: any, b: number, c: number, d: number, e: number, f: number, g: number) => any;
    readonly wasmdb_openBrowserWithSelfSignedProof: (a: any, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number, l: number, m: number) => any;
    readonly wasmdb_openMemory: (a: number, b: number, c: number, d: number) => [number, number, number];
    readonly wasmdb_openMemoryAsBackend: (a: number, b: number, c: number, d: number) => [number, number, number];
    readonly wasmdb_openMemoryWithSelfSignedProof: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number) => [number, number, number];
    readonly wasmdb_registerSchema: (a: number, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly wasmdb_requestDeletePermissionAdvice: (a: number, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly wasmdb_requestInsertPermissionAdvice: (a: number, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly wasmdb_requestReadPermissionAdvice: (a: number, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly wasmdb_requestUpdatePermissionAdvice: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => [number, number, number];
    readonly wasmdb_restore: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: any) => [number, number, number];
    readonly wasmdb_restoreInTransaction: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: any) => [number, number];
    readonly wasmdb_rollbackTransaction: (a: number, b: number, c: number) => [number, number];
    readonly wasmdb_seedForegroundTxTimeHighWater: (a: number, b: bigint) => [number, number];
    readonly wasmdb_setIdentityClaims: (a: number, b: number, c: number, d: any) => [number, number];
    readonly wasmdb_setLargeValueStagingPolicy: (a: number, b: number, c: number, d: number, e: number) => [number, number];
    readonly wasmdb_setNonDurableClient: (a: number) => [number, number];
    readonly wasmdb_setRemoteLinkHint: (a: number, b: number, c: number) => [number, number];
    readonly wasmdb_setSessionClaims: (a: number, b: any) => [number, number, number];
    readonly wasmdb_setSlowQueryThresholdMs: (a: number, b: number) => [number, number];
    readonly wasmdb_setTickScheduler: (a: number, b: any) => void;
    readonly wasmdb_subscribe: (a: number, b: number, c: number, d: any, e: number, f: number, g: any) => [number, number, number];
    readonly wasmdb_takeSlowQueryReport: (a: number, b: number, c: number) => [number, number, number, number];
    readonly wasmdb_tick: (a: number) => any;
    readonly wasmdb_update: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: any) => [number, number, number];
    readonly wasmdb_updateInTransaction: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: any) => [number, number];
    readonly wasmdb_updateLargeValues: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: any, i: number, j: number) => [number, number, number];
    readonly wasmdb_updateLargeValuesInTransaction: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: any, k: number, l: number) => [number, number];
    readonly wasmdb_uploadStatus: (a: number) => [number, number, number];
    readonly wasmdb_upsert: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: any) => [number, number, number];
    readonly wasmdb_upsertInTransaction: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: any) => [number, number];
    readonly wasmdb_waitForPendingWrites: (a: number, b: number, c: number, d: number) => any;
    readonly wasmdb_wireFeatures: (a: number) => number;
    readonly wasmpendingsubscription_cancel: (a: number) => void;
    readonly wasmpendingsubscription_poll: (a: number) => [number, number, number];
    readonly wasmpendingsubscription_setWake: (a: number, b: any) => void;
    readonly wasmpermissionadvicerequest_cancel: (a: number) => void;
    readonly wasmpermissionadvicerequest_promise: (a: number) => any;
    readonly wasmstreamingmutation_abort: (a: number) => any;
    readonly wasmstreamingmutation_finish: (a: number) => any;
    readonly wasmstreamingmutation_finishInTransaction: (a: number) => [number, number];
    readonly wasmstreamingmutation_push: (a: number, b: number, c: number) => any;
    readonly wasmtransport_auxiliaryOutboundReady: (a: number) => any;
    readonly wasmtransport_auxiliaryReceiveTimeoutMs: (a: number) => number;
    readonly wasmtransport_clearOutboundScheduler: (a: number) => void;
    readonly wasmtransport_close: (a: number) => number;
    readonly wasmtransport_expireAuxiliaryReceive: (a: number) => void;
    readonly wasmtransport_recvAuxiliaryWireFrames: (a: number, b: number, c: number) => any;
    readonly wasmtransport_recvWireFrames: (a: number) => any;
    readonly wasmtransport_routeAuxiliaryWireFrame: (a: number, b: number, c: number) => any;
    readonly wasmtransport_sendWireFrame: (a: number, b: number, c: number) => void;
    readonly wasmtransport_sendWireFrames: (a: number, b: any) => void;
    readonly wasmtransport_setAuxiliaryTraceEnabled: (a: number, b: number) => void;
    readonly wasmtransport_setOutboundScheduler: (a: number, b: any) => void;
    readonly wasmtransport_takeAuxiliaryTrace: (a: number) => any;
    readonly wasmtransport_tick: (a: number) => any;
    readonly wasmtransport_updateAuthenticatedClaims: (a: number, b: any) => [number, number, number];
    readonly wasmtransport_upstreamRefusal: (a: number) => any;
    readonly wasmwrite_close: (a: number) => number;
    readonly wasmwrite_payload: (a: number) => [number, number];
    readonly wasmwrite_rowId: (a: number) => [number, number];
    readonly wasmwrite_txId: (a: number) => [number, number];
    readonly wasmwrite_wait: (a: number, b: number, c: number, d: number) => [number, number, number];
    readonly wasmwrite_writeState: (a: number) => [number, number, number];
    readonly init: () => void;
    readonly setJsonSchemaValidator: (a: any) => void;
    readonly drainTraceEntries: () => any;
    readonly subscribeTraceEntries: (a: any) => any;
    readonly captureTextAnchor: (a: number, b: number, c: number, d: number, e: number, f: any) => [number, number, number];
    readonly captureTextRange: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number];
    readonly resolveTextAnchor: (a: any, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly resolveTextRange: (a: any, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly rust_sqlite_wasm_abort: () => void;
    readonly rust_sqlite_wasm_assert_fail: (a: number, b: number, c: number, d: number) => void;
    readonly rust_sqlite_wasm_calloc: (a: number, b: number) => number;
    readonly rust_sqlite_wasm_free: (a: number) => void;
    readonly rust_sqlite_wasm_getentropy: (a: number, b: number) => number;
    readonly rust_sqlite_wasm_localtime: (a: number) => number;
    readonly rust_sqlite_wasm_malloc: (a: number) => number;
    readonly rust_sqlite_wasm_realloc: (a: number, b: number) => number;
    readonly sqlite3_os_end: () => number;
    readonly sqlite3_os_init: () => number;
    readonly wasm_bindgen__convert__closures_____invoke__h80aa994bc8ddbf76: (a: number, b: number, c: any) => [number, number];
    readonly wasm_bindgen__convert__closures_____invoke__hbfb78b278dc7e98e: (a: number, b: number, c: any) => [number, number];
    readonly wasm_bindgen__convert__closures_____invoke__h6260fd5b023f962b: (a: number, b: number, c: any, d: any) => void;
    readonly wasm_bindgen__convert__closures_____invoke__h6fa7664e97f9e29f: (a: number, b: number, c: any) => any;
    readonly wasm_bindgen__convert__closures_____invoke__h71dc611491ac6d65: (a: number, b: number, c: any) => void;
    readonly wasm_bindgen__convert__closures_____invoke__hc3324ad424e8006d: (a: number, b: number) => void;
    readonly wasm_bindgen__convert__closures_____invoke__h5c6b66ff986e113b: (a: number, b: number) => void;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_destroy_closure: (a: number, b: number) => void;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __externref_drop_slice: (a: number, b: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
