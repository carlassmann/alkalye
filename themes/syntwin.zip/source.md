# Syntwin theme

Alkalye supplies its built-in baseline at render time. This source contains only the Syntwin document and slideshow treatment. The final CSS fence contains a packaged local asset; prose is ignored by the importer.

## Syntwin overrides

```css theme
:scope[data-appearance="light"] {
	--syntwin-paper: #f6f6f2;
	--syntwin-ink: #050505;
	--syntwin-blue: #1769ff;
	--syntwin-lime: #c6ff2e;
	--syntwin-gray: #6a6a66;
	--syntwin-rule: color-mix(
		in srgb,
		var(--syntwin-ink) 14%,
		var(--syntwin-paper)
	);
	--syntwin-code: color-mix(
		in srgb,
		var(--syntwin-blue) 7%,
		var(--syntwin-paper)
	);
	background: var(--syntwin-paper);
}

:scope[data-appearance="dark"] {
	--syntwin-paper: #11110f;
	--syntwin-ink: #f6f6f2;
	--syntwin-blue: #8bb5ff;
	--syntwin-lime: #c6ff2e;
	--syntwin-gray: #b5b5ad;
	--syntwin-rule: color-mix(
		in srgb,
		var(--syntwin-ink) 18%,
		var(--syntwin-paper)
	);
	--syntwin-code: color-mix(
		in srgb,
		var(--syntwin-blue) 12%,
		var(--syntwin-paper)
	);
	background: var(--syntwin-paper);
}

.document,
.theme[data-mode="slideshow"] {
	background: var(--syntwin-paper);
	color: var(--syntwin-ink);
	font-family: "Geist", Arial, sans-serif;
}

.document {
	max-width: none;
	padding: 0;
}

.document .syntwin-document {
	max-width: 76ch;
	margin: 0 auto;
	padding: clamp(1.5rem, 4vw, 4rem) clamp(1.25rem, 4vw, 3.5rem) 5rem;
}

.document .syntwin-document-header {
	margin: 0 0 clamp(2rem, 5vw, 4.5rem);
	border-bottom: 1px solid var(--syntwin-rule);
}

.document .syntwin-brand-line {
	display: flex;
	align-items: center;
	min-height: 2.75rem;
	gap: 0.55rem;
	color: var(--syntwin-ink);
	font-size: 0.8rem;
	letter-spacing: -0.02em;
}

.document .syntwin-mark {
	display: inline-block;
	width: 1.25rem;
	height: 0.65rem;
	background: var(--syntwin-blue);
	mask: var(--syntwin-mark) center / contain no-repeat;
	-webkit-mask: var(--syntwin-mark) center / contain no-repeat;
}

.document .syntwin-wordmark {
	font-weight: 700;
}

.document .syntwin-page-footer {
	margin-top: 3rem;
	text-align: center;
	font:
		400 0.75rem/1 "Geist",
		Arial,
		sans-serif;
	color: var(--syntwin-gray);
}

.document .content {
	max-width: none;
	color: var(--syntwin-ink);
	font-family: "Geist", Arial, sans-serif;
	font-size: 1.02rem;
	line-height: 1.72;
	--tw-prose-body: var(--syntwin-ink);
	--tw-prose-headings: var(--syntwin-ink);
	--tw-prose-bold: var(--syntwin-ink);
	--tw-prose-links: var(--syntwin-blue);
	--tw-prose-quotes: var(--syntwin-ink);
	--tw-prose-code: var(--syntwin-ink);
	--tw-prose-counters: var(--syntwin-gray);
	--tw-prose-bullets: var(--syntwin-blue);
	--tw-prose-hr: var(--syntwin-rule);
	--tw-prose-quote-borders: var(--syntwin-lime);
	--tw-prose-th-borders: var(--syntwin-rule);
	--tw-prose-td-borders: var(--syntwin-rule);
	--tw-prose-pre-bg: var(--syntwin-code);
	--tw-prose-pre-code: var(--syntwin-ink);
}

.document .content h1,
.document .content h2,
.document .content h3 {
	color: var(--syntwin-ink);
	letter-spacing: -0.045em;
}

.document .content h1 {
	max-width: 19ch;
	font-size: clamp(2.3rem, 6vw, 4.4rem);
	line-height: 0.98;
}

.document .content h2 {
	margin-top: 1.5rem;
	padding-top: 0.45em;
	border-top: 1px solid var(--syntwin-rule);
}

.document .content a {
	color: var(--syntwin-blue);
	text-decoration-color: color-mix(
		in srgb,
		var(--syntwin-blue) 42%,
		transparent
	);
	text-underline-offset: 0.18em;
}

.document .content blockquote {
	border-inline-start-color: var(--syntwin-lime);
}

.document .content code,
.document .content pre {
	font-family: "Geist Mono", ui-monospace, monospace;
}

.document .content pre {
	border: 1px solid var(--syntwin-rule);
	border-radius: 0;
	background: var(--syntwin-code);
}

.document .content table :is(th, td) {
	border-color: var(--syntwin-rule);
}

.theme[data-mode="slideshow"] {
	--slide-background: var(--syntwin-paper);
	--slide-foreground: var(--syntwin-ink);
	--slide-accent: var(--syntwin-blue);
}

.theme[data-mode="slideshow"] .slide {
	position: relative;
	background: var(--syntwin-paper);
	color: var(--syntwin-ink);
}

.theme[data-mode="slideshow"] .slide::before {
	position: absolute;
	left: 6%;
	bottom: 6%;
	width: 1.45rem;
	height: 1rem;
	background: var(--syntwin-ink);
	mask: var(--syntwin-mark) center / contain no-repeat;
	-webkit-mask: var(--syntwin-mark) center / contain no-repeat;
	opacity: 0.22;
	content: "";
	pointer-events: none;
}

.theme[data-mode="slideshow"] .slide::after {
	position: absolute;
	left: calc(6% + 2rem);
	bottom: 6%;
	color: var(--syntwin-ink);
	font:
		700 1rem/1 "Geist",
		Arial,
		sans-serif;
	letter-spacing: -0.04em;
	opacity: 0.22;
	content: "syntwin";
	pointer-events: none;
}

.theme[data-mode="slideshow"] :is(h1, h2, h3) {
	color: var(--syntwin-ink);
	font-family: "Geist", Arial, sans-serif;
	letter-spacing: -0.055em;
}

.theme[data-mode="slideshow"] h1 {
	max-width: 15ch;
}

.theme[data-mode="slideshow"] a {
	color: var(--syntwin-blue);
}

.theme[data-mode="slideshow"] blockquote {
	border-inline-start-color: var(--syntwin-lime);
}

.theme[data-mode="slideshow"] :is(code, pre) {
	font-family: "Geist Mono", ui-monospace, monospace;
}

@media print {
	@page {
		size: A4;
		margin: 18mm;
		@bottom-center {
			content: "syntwin.ai";
			font:
				400 9pt "Geist",
				Arial,
				sans-serif;
			color: #6a6a66;
		}
	}

	:scope,
	.document,
	.document .syntwin-document,
	.document .content {
		--syntwin-paper: #ffffff;
		background: #ffffff !important;
		color: #050505 !important;
	}

	.document,
	.document .syntwin-document {
		max-width: none;
		padding: 0;
	}

	.document .syntwin-document-header {
		margin-bottom: 10mm;
	}

	.document .syntwin-page-footer {
		display: none;
	}

	.document .content h1,
	.document .content h2,
	.document .content h3,
	.document .content table,
	.document .content blockquote,
	.document .content pre {
		break-inside: avoid;
		page-break-inside: avoid;
	}

	.document .content h2,
	.document .content h3 {
		break-after: avoid;
		page-break-after: avoid;
	}
}
```

## Packaged brand assets

```css theme
/* Canonical Syntwin mark. */
:scope {
	--syntwin-mark: url("data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%22-32%200%201029%20480%22%3E%3Cpath%20d%3D%22M416%2098.0902C440%2046.0902%20498%208.09017%20563%201.09017C579%20-0.90983%20748%200.0901699%20760%202.09017C860%2018.0902%20937%2090.0902%20959%20186.09C988%20315.09%20908%20444.09%20781%20473.09C755%20478.09%20736%20479.09%20680%20479.09H537H524L540%20472.09C597%20444.09%20629%20377.5%20629%20345.5V338.09C633%20338.09%20681%20337.09%20690%20337.09C699%20337.09%20710%20337.09%20723%20332.09C806%20305.09%20814%20190.09%20736%20152.09C715%20142.09%20670%20142.09%20525%20142.09H403V139.09C406%20121.09%20409%20112.09%20416%2098.0902Z%22%2F%3E%3Cpath%20d%3D%22M553.942%20381C529.942%20433%20471.942%20471%20406.942%20478C390.942%20480%20216.942%20479%20204.942%20477C104.942%20461%2027.9417%20389%205.94167%20293C-23.0583%20164%2056.9417%2035.0001%20183.942%206.00012L184.594%205.87469C210.024%200.983337%20215.135%200.000121832%20289.942%200.000128372L433.5%200.000140922L445.5%200.000141971L430.5%207.00014C373.5%2035.0001%20344%2080.5%20340.942%20132C340.734%20135.5%20340.942%20141%20340.942%20141C339%20141%20313.942%20142%20279.942%20142C271.5%20142%20254.942%20142%20241.942%20147C158.942%20174%20150.942%20289%20228.942%20327C249.942%20337%20299.942%20337%20444.942%20337L566.942%20337L566.942%20340C563.942%20358%20560.942%20367%20553.942%20381Z%22%2F%3E%3C%2Fsvg%3E");
}
```

## Document wrapper

```html document
<section class="syntwin-document">
	<header class="syntwin-document-header">
		<div class="syntwin-brand-line">
			<span class="syntwin-mark" aria-hidden="true"></span>
			<span class="syntwin-wordmark">syntwin</span>
		</div>
	</header>
	<main data-content></main>
	<footer class="syntwin-page-footer">syntwin.ai</footer>
</section>
```
